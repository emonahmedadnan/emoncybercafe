"use client";

import { useEffect, type ReactNode } from "react";
import { AlertTriangle, Loader2, X, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { STATUS_META, taka } from "@/lib/format";

/* ------------------------------- Primitives ------------------------------ */

export const inputCls =
  "w-full rounded-xl border border-ink-200 bg-white px-3.5 py-2.5 text-[14.5px] text-ink-900 placeholder:text-ink-300 shadow-sm outline-none transition focus:border-brand-500 focus:ring-4 focus:ring-brand-500/15 disabled:opacity-50";

export function Field({
  label,
  children,
  hint,
  optional,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
  optional?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between text-[13px] font-semibold text-ink-700">
        {label}
        {optional && <span className="text-[11px] font-normal text-ink-400">ঐচ্ছিক</span>}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-ink-400">{hint}</span>}
    </label>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-5 w-5 animate-spin", className)} />;
}

/* --------------------------------- Avatar -------------------------------- */

const AVATAR_COLORS = [
  "bg-brand-100 text-brand-700",
  "bg-amber-100 text-amber-700",
  "bg-sky-100 text-sky-700",
  "bg-violet-100 text-violet-700",
  "bg-rose-100 text-rose-700",
  "bg-teal-100 text-teal-700",
  "bg-indigo-100 text-indigo-700",
  "bg-orange-100 text-orange-700",
];

export function Avatar({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  const color = AVATAR_COLORS[hash % AVATAR_COLORS.length];
  const initial = name.trim().charAt(0) || "অ";
  return (
    <span
      className={cn(
        "grid h-10 w-10 shrink-0 place-items-center rounded-full text-base font-bold",
        color,
        className
      )}
    >
      {initial}
    </span>
  );
}

/* --------------------------------- Money --------------------------------- */

export function Money({ amount, className }: { amount: number; className?: string }) {
  return <span className={cn("tabular-nums font-bold", className)}>{taka(amount)}</span>;
}

/* ------------------------------ Status badge ----------------------------- */

export function StatusBadge({ status }: { status: string }) {
  const meta = STATUS_META[status] ?? STATUS_META.pending;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset",
        meta.badge
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </span>
  );
}

/* --------------------------------- Modal --------------------------------- */

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div
        className="absolute inset-0 bg-ink-950/45 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />
      <div
        className={cn(
          "relative flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-t-3xl bg-cream shadow-lift animate-fade-up sm:rounded-3xl",
          wide ? "sm:max-w-2xl" : "sm:max-w-lg"
        )}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-start justify-between gap-4 border-b border-ink-100 px-6 pb-4 pt-5 sm:px-7">
          <div>
            <h3 className="text-lg font-bold text-ink-950">{title}</h3>
            {subtitle && <p className="mt-0.5 text-[13px] text-ink-500">{subtitle}</p>}
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-ink-400 transition hover:bg-ink-100 hover:text-ink-800"
            aria-label="বন্ধ করুন"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-6 py-5 sm:px-7">{children}</div>
      </div>
    </div>
  );
}

/* ---------------------------- Confirm dialog ----------------------------- */

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = "মুছে ফেলুন",
  busy,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  busy?: boolean;
}) {
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <div className="flex items-start gap-3.5">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-red-100 text-red-600">
          <AlertTriangle className="h-5 w-5" />
        </span>
        <p className="pt-1.5 text-[14.5px] leading-relaxed text-ink-600">{message}</p>
      </div>
      <div className="mt-6 flex justify-end gap-2.5">
        <button
          onClick={onClose}
          className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:bg-ink-50"
        >
          বাতিল
        </button>
        <button
          onClick={onConfirm}
          disabled={busy}
          className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-red-700 disabled:opacity-60"
        >
          {busy && <Spinner className="h-4 w-4" />}
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

/* ------------------------------ Empty state ------------------------------ */

export function EmptyState({
  icon: Icon,
  title,
  message,
  actionLabel,
  onAction,
}: {
  icon: LucideIcon;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <span className="relative grid h-16 w-16 place-items-center rounded-3xl bg-ink-100/70 text-ink-400">
        <Icon className="h-7 w-7" />
        <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-coin-400 ring-4 ring-coin-100" />
      </span>
      <h4 className="mt-4 text-[16px] font-bold text-ink-800">{title}</h4>
      <p className="mt-1 max-w-sm text-[13.5px] leading-relaxed text-ink-500">{message}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="mt-5 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

/* ------------------------------ Skeleton row ----------------------------- */

export function CardSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn("animate-pulse rounded-2xl border border-ink-100 bg-cream p-5", className)}>
      <div className="h-3.5 w-24 rounded-full bg-ink-100" />
      <div className="mt-3 h-7 w-32 rounded-full bg-ink-100" />
    </div>
  );
}
