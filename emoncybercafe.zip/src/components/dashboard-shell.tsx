"use client";

import { useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  ChartColumn,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Users,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { todayBn } from "@/lib/format";
import { Avatar } from "@/components/ui";
import { ToastProvider } from "@/components/toast";

const NAV = [
  { href: "/dashboard", label: "ড্যাশবোর্ড", icon: LayoutDashboard, exact: true },
  { href: "/dashboard/orders", label: "কাজের তালিকা", icon: ClipboardList },
  { href: "/dashboard/customers", label: "গ্রাহক", icon: Users },
  { href: "/dashboard/services", label: "সার্ভিস সমূহ", icon: Package },
  { href: "/dashboard/reports", label: "আয়ের রিপোর্ট", icon: ChartColumn },
];

const TITLES: Record<string, { title: string; sub: string }> = {
  "/dashboard": { title: "ড্যাশবোর্ড", sub: "আপনার দোকানের সার্বিক চিত্র" },
  "/dashboard/orders": { title: "কাজের তালিকা", sub: "সব অর্ডার ও তাদের অবস্থা" },
  "/dashboard/customers": { title: "গ্রাহক", sub: "আপনার সব গ্রাহকের তথ্য" },
  "/dashboard/services": { title: "সার্ভিস সমূহ", sub: "সেবা ও মূল্য তালিকা" },
  "/dashboard/reports": { title: "আয়ের রিপোর্ট", sub: "মাসিক আয় ও লেনদেনের খাতা" },
};

type Props = {
  user: { name: string; email: string; shopName: string };
  children: ReactNode;
};

export default function DashboardShell({ user, children }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  const meta =
    TITLES[
      Object.keys(TITLES).find((k) =>
        k === "/dashboard" ? pathname === k : pathname.startsWith(k)
      ) ?? "/dashboard"
    ];

  async function logout() {
    setLoggingOut(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const sidebar = (
    <div className="flex h-full flex-col">
      <Link href="/dashboard" className="flex items-center gap-3 px-5 pb-6 pt-6">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-700 text-xl font-bold text-white shadow-lift">
          ই
        </div>
        <div className="min-w-0">
          <div className="truncate text-[15px] font-bold leading-tight text-white">
            {user.shopName}
          </div>
          <div className="text-[11px] text-white/45">দোকান ব্যবস্থাপনা</div>
        </div>
      </Link>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3">
        <p className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-white/35">
          মেনু
        </p>
        {NAV.map((item) => {
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMenuOpen(false)}
              className={cn(
                "group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-[14.5px] font-semibold transition-all",
                active
                  ? "bg-white/[0.1] text-white shadow-sm ring-1 ring-inset ring-white/10"
                  : "text-white/55 hover:bg-white/[0.05] hover:text-white"
              )}
            >
              <item.icon
                className={cn(
                  "h-[18px] w-[18px] transition",
                  active ? "text-brand-300" : "text-white/40 group-hover:text-white/70"
                )}
              />
              {item.label}
              {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-brand-400" />}
            </Link>
          );
        })}
      </nav>

      <div className="p-3">
        <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-4">
          <div className="flex items-center gap-3">
            <Avatar name={user.name} className="h-9 w-9 ring-2 ring-white/10" />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[13.5px] font-bold text-white">{user.name}</div>
              <div className="truncate text-[11px] text-white/40">{user.email}</div>
            </div>
          </div>
          <button
            onClick={logout}
            disabled={loggingOut}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] py-2 text-[13px] font-semibold text-white/70 transition hover:bg-red-500/15 hover:text-red-300 disabled:opacity-50"
          >
            <LogOut className="h-3.5 w-3.5" />
            {loggingOut ? "লগআউট হচ্ছে..." : "লগআউট"}
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <ToastProvider>
      <div className="min-h-dvh bg-paper">
        {/* Desktop sidebar */}
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-72 bg-ink-950 lg:block">
          <div className="dot-grid absolute inset-0 opacity-40" />
          <div className="relative h-full">{sidebar}</div>
        </aside>

        {/* Mobile drawer */}
        {menuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div
              className="absolute inset-0 bg-ink-950/50 backdrop-blur-sm animate-fade-in"
              onClick={() => setMenuOpen(false)}
            />
            <aside className="absolute inset-y-0 left-0 w-72 bg-ink-950 shadow-lift animate-fade-up">
              <button
                onClick={() => setMenuOpen(false)}
                className="absolute right-3 top-5 z-10 rounded-lg p-1.5 text-white/60 hover:bg-white/10 hover:text-white"
                aria-label="মেনু বন্ধ করুন"
              >
                <X className="h-5 w-5" />
              </button>
              {sidebar}
            </aside>
          </div>
        )}

        <div className="lg:pl-72">
          {/* Topbar */}
          <header className="sticky top-0 z-20 border-b border-ink-100/80 bg-paper/85 backdrop-blur-md">
            <div className="mx-auto flex max-w-[1380px] items-center gap-3 px-4 py-3.5 sm:px-6 lg:px-10">
              <button
                onClick={() => setMenuOpen(true)}
                className="rounded-xl border border-ink-200 bg-white p-2 text-ink-700 shadow-sm lg:hidden"
                aria-label="মেনু খুলুন"
              >
                <Menu className="h-5 w-5" />
              </button>
              <div className="min-w-0 flex-1">
                <h1 className="truncate text-lg font-bold leading-tight text-ink-950 sm:text-xl">
                  {meta.title}
                </h1>
                <p className="hidden truncate text-xs text-ink-400 sm:block">{meta.sub}</p>
              </div>
              <div className="hidden items-center gap-2 rounded-full border border-ink-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-ink-600 shadow-sm md:flex">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
                {todayBn()}
              </div>
              <Avatar name={user.name} className="h-9 w-9 shadow-sm lg:hidden" />
            </div>
          </header>

          <main className="mx-auto max-w-[1380px] px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
            {children}
          </main>
        </div>
      </div>
    </ToastProvider>
  );
}
