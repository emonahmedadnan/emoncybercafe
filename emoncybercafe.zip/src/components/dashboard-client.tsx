"use client";

import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Banknote,
  ClipboardList,
  Hourglass,
  TrendingUp,
  Users,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { bnDateShort, STATUS_META, taka, toBn } from "@/lib/format";
import { Avatar, EmptyState, StatusBadge } from "@/components/ui";
import type { OrderRow } from "@/lib/queries";

type Stats = {
  totalCustomers: number;
  activeOrders: number;
  totalOrders: number;
  todayIncome: number;
  monthIncome: number;
  totalDue: number;
  statusCounts: Record<string, number>;
  weekIncome: Array<{ label: string; amount: number; isToday: boolean }>;
  topServices: Array<{ name: string; count: number; revenue: number }>;
};

export default function DashboardClient({
  stats,
  recentOrders,
  userName,
}: {
  stats: Stats;
  recentOrders: OrderRow[];
  userName: string;
}) {
  const maxWeek = Math.max(...stats.weekIncome.map((d) => d.amount), 1);
  const statusTotal = Object.values(stats.statusCounts).reduce((a, b) => a + b, 0);

  // conic gradient for donut
  let acc = 0;
  const donutSegments = Object.entries(stats.statusCounts)
    .filter(([, v]) => v > 0)
    .map(([k, v]) => {
      const from = (acc / Math.max(statusTotal, 1)) * 360;
      acc += v;
      const to = (acc / Math.max(statusTotal, 1)) * 360;
      return `${STATUS_META[k]?.bar ?? "#94a3b8"} ${from}deg ${to}deg`;
    });
  const donutBg =
    statusTotal > 0
      ? `conic-gradient(${donutSegments.join(", ")})`
      : "conic-gradient(#e5e7eb 0deg 360deg)";

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "সুপ্রভাত" : hour < 16 ? "শুভ দুপুর" : hour < 19 ? "শুভ বিকেল" : "শুভ সন্ধ্যা";

  const cards = [
    {
      label: "আজকের আয়",
      value: taka(stats.todayIncome),
      sub: `এই মাসে ${taka(stats.monthIncome)}`,
      icon: Banknote,
      iconCls: "bg-brand-100 text-brand-700",
      accent: "from-brand-500/10",
    },
    {
      label: "মোট গ্রাহক",
      value: toBn(stats.totalCustomers),
      sub: "জমায়েত গ্রাহক তালিকা",
      icon: Users,
      iconCls: "bg-sky-100 text-sky-700",
      accent: "from-sky-500/10",
    },
    {
      label: "চলমান কাজ",
      value: toBn(stats.activeOrders),
      sub: `মোট অর্ডার ${toBn(stats.totalOrders)}`,
      icon: Hourglass,
      iconCls: "bg-coin-100 text-coin-700",
      accent: "from-coin-500/10",
    },
    {
      label: "বাকি আছে",
      value: taka(stats.totalDue),
      sub: "গ্রাহকদের কাছে পাওনা",
      icon: Wallet,
      iconCls: "bg-rose-100 text-rose-600",
      accent: "from-rose-500/10",
    },
  ];

  return (
    <div className="space-y-5">
      {/* Greeting banner */}
      <div className="relative overflow-hidden rounded-3xl bg-ink-950 p-6 text-white shadow-lift sm:p-8">
        <div className="dot-grid absolute inset-0" />
        <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-brand-500/25 blur-[90px]" />
        <div className="absolute -bottom-28 right-24 h-52 w-52 rounded-full bg-coin-500/20 blur-[80px]" />
        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-brand-300">{greeting},</p>
            <h2 className="mt-1 text-2xl font-bold sm:text-3xl">{userName}</h2>
            <p className="mt-2 max-w-md text-[13.5px] leading-relaxed text-white/55">
              আজ পর্যন্ত <span className="font-bold text-coin-300">{toBn(stats.activeOrders)}টি</span> কাজ
              চলমান আছে এবং আজকের আয়{" "}
              <span className="font-bold text-coin-300">{taka(stats.todayIncome)}</span>
            </p>
          </div>
          <Link
            href="/dashboard/orders?new=1"
            className="group inline-flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-ink-950 shadow-lift transition hover:bg-brand-50 active:scale-[0.98]"
          >
            নতুন কাজ যোগ করুন
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3.5 xl:grid-cols-4">
        {cards.map((c, i) => (
          <div
            key={c.label}
            className="group relative overflow-hidden rounded-2xl border border-ink-100 bg-cream p-4 shadow-soft transition-shadow hover:shadow-lift sm:p-5"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className={cn("absolute inset-0 bg-gradient-to-br to-transparent opacity-0 transition-opacity group-hover:opacity-100", c.accent)} />
            <div className="relative">
              <div className="flex items-center justify-between">
                <span className={cn("grid h-10 w-10 place-items-center rounded-xl", c.iconCls)}>
                  <c.icon className="h-5 w-5" />
                </span>
                <ArrowUpRight className="h-4 w-4 text-ink-200 transition group-hover:text-ink-400" />
              </div>
              <div className="mt-3.5 text-xl font-bold tracking-tight text-ink-950 sm:text-2xl">
                {c.value}
              </div>
              <div className="mt-0.5 text-xs font-semibold text-ink-500">{c.label}</div>
              <div className="mt-1 hidden text-[11px] text-ink-400 sm:block">{c.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        {/* Weekly income */}
        <div className="rounded-2xl border border-ink-100 bg-cream p-5 shadow-soft sm:p-6 lg:col-span-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-[15px] font-bold text-ink-950">সাপ্তাহিক আয়</h3>
              <p className="text-xs text-ink-400">গত ৭ দিনের লেনদেন</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1.5 text-xs font-bold text-brand-700 ring-1 ring-inset ring-brand-200">
              <TrendingUp className="h-3.5 w-3.5" />
              {taka(stats.weekIncome.reduce((s, d) => s + d.amount, 0))}
            </span>
          </div>
          <div className="mt-6 flex h-44 items-end gap-2 sm:gap-3">
            {stats.weekIncome.map((d, i) => (
              <div key={i} className="group flex flex-1 flex-col items-center gap-2">
                <div className="relative flex h-36 w-full items-end justify-center">
                  <span className="pointer-events-none absolute -top-2 rounded-lg bg-ink-950 px-2 py-1 text-[10px] font-bold text-white opacity-0 shadow-lift transition group-hover:-top-4 group-hover:opacity-100">
                    {taka(d.amount)}
                  </span>
                  <div
                    className={cn(
                      "w-full max-w-10 rounded-xl transition-all duration-500 group-hover:scale-x-105",
                      d.isToday
                        ? "bg-gradient-to-t from-brand-600 to-brand-400 shadow-[0_8px_20px_-8px] shadow-brand-500/50"
                        : d.amount > 0
                          ? "bg-ink-200/80 group-hover:bg-brand-300"
                          : "bg-ink-100"
                    )}
                    style={{ height: `${Math.max((d.amount / maxWeek) * 100, 4)}%` }}
                  />
                </div>
                <span
                  className={cn(
                    "text-[11px] font-semibold",
                    d.isToday ? "text-brand-700" : "text-ink-400"
                  )}
                >
                  {d.isToday ? "আজ" : d.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Status donut */}
        <div className="rounded-2xl border border-ink-100 bg-cream p-5 shadow-soft sm:p-6 lg:col-span-2">
          <h3 className="text-[15px] font-bold text-ink-950">কাজের অবস্থা</h3>
          <p className="text-xs text-ink-400">সব অর্ডারের সারসংক্ষেপ</p>
          <div className="mt-5 flex items-center gap-5">
            <div
              className="relative h-32 w-32 shrink-0 rounded-full"
              style={{ background: donutBg }}
            >
              <div className="absolute inset-3 grid place-items-center rounded-full bg-cream">
                <div className="text-center">
                  <div className="text-2xl font-bold text-ink-950">{toBn(statusTotal)}</div>
                  <div className="text-[10px] font-semibold text-ink-400">মোট কাজ</div>
                </div>
              </div>
            </div>
            <ul className="flex-1 space-y-2.5">
              {Object.entries(stats.statusCounts).map(([k, v]) => (
                <li key={k} className="flex items-center gap-2.5 text-[13px]">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: STATUS_META[k]?.bar }}
                  />
                  <span className="flex-1 font-medium text-ink-600">{STATUS_META[k]?.label}</span>
                  <span className="font-bold text-ink-900">{toBn(v)}</span>
                </li>
              ))}
            </ul>
          </div>

          {stats.topServices.length > 0 && (
            <div className="mt-5 border-t border-ink-100 pt-4">
              <p className="mb-2.5 text-xs font-bold text-ink-500">জনপ্রিয় সার্ভিস</p>
              <ul className="space-y-2">
                {stats.topServices.slice(0, 3).map((s) => (
                  <li key={s.name} className="flex items-center gap-2 text-[13px]">
                    <span className="flex-1 truncate font-medium text-ink-700">{s.name}</span>
                    <span className="rounded-full bg-ink-100/70 px-2 py-0.5 text-[11px] font-bold text-ink-600">
                      {toBn(s.count)}টি
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Recent orders */}
      <div className="overflow-hidden rounded-2xl border border-ink-100 bg-cream shadow-soft">
        <div className="flex items-center justify-between gap-3 border-b border-ink-100 px-5 py-4 sm:px-6">
          <div>
            <h3 className="text-[15px] font-bold text-ink-950">সাম্প্রতিক কাজ</h3>
            <p className="text-xs text-ink-400">সর্বশেষ নেওয়া অর্ডারগুলো</p>
          </div>
          <Link
            href="/dashboard/orders"
            className="inline-flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3.5 py-2 text-xs font-bold text-ink-700 shadow-sm transition hover:border-brand-300 hover:text-brand-700"
          >
            সব দেখুন
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        {recentOrders.length === 0 ? (
          <EmptyState
            icon={ClipboardList}
            title="এখনো কোনো কাজ নেই"
            message="প্রথম কাজটি যোগ করুন — গ্রাহকের নাম, কাজের ধরন আর টাকার পরিমাণ দিলেই হিসাব শুরু।"
          />
        ) : (
          <ul className="divide-y divide-ink-100/80">
            {recentOrders.map((o) => (
              <li key={o.id} className="flex items-center gap-3.5 px-5 py-3.5 transition hover:bg-white/70 sm:px-6">
                <Avatar name={o.customer.name} className="h-9.5 w-9.5 text-sm" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-[14px] font-bold text-ink-900">
                      {o.customer.name}
                    </span>
                    <span className="hidden text-[11px] font-medium text-ink-300 sm:inline">
                      {bnDateShort(o.createdAt)}
                    </span>
                  </div>
                  <div className="truncate text-xs text-ink-500">
                    {o.serviceName}
                    {o.quantity > 1 && <span> × {toBn(o.quantity)}</span>}
                  </div>
                </div>
                <div className="hidden text-right sm:block">
                  <div className="text-[13.5px] font-bold text-ink-900">{taka(o.totalAmount)}</div>
                  {o.totalAmount - o.paidAmount > 0 ? (
                    <div className="text-[11px] font-semibold text-rose-600">
                      বাকি {taka(o.totalAmount - o.paidAmount)}
                    </div>
                  ) : (
                    <div className="text-[11px] font-semibold text-brand-600">পরিশোধিত</div>
                  )}
                </div>
                <StatusBadge status={o.status} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
