"use client";

import { useState } from "react";
import {
  Banknote,
  CalendarDays,
  ChartColumn,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  HandCoins,
  Receipt,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { bnDateTime, orderNo, taka, toBn } from "@/lib/format";
import { EmptyState, Spinner } from "@/components/ui";
import { useToast } from "@/components/toast";

type LedgerItem = {
  id: number;
  amount: number;
  method: string;
  note: string | null;
  createdAt: string;
  orderId: number;
  customerName: string;
  serviceName: string;
};

type Report = {
  month: string;
  monthLabel: string;
  totalIncome: number;
  paymentsCount: number;
  ordersCount: number;
  ordersBilled: number;
  ordersCollected: number;
  daily: Array<{ day: number; amount: number }>;
  byMethod: Record<string, number>;
  ledger: LedgerItem[];
};

const METHOD_LABEL: Record<string, string> = {
  cash: "নগদ",
  bkash: "বিকাশ",
  nagad: "নগদ অ্যাপ",
};

export default function ReportsClient({ initialReport }: { initialReport: Report }) {
  const { toast } = useToast();
  const [report, setReport] = useState<Report>(initialReport);
  const [loading, setLoading] = useState(false);

  async function shiftMonth(delta: number) {
    const [y, m] = report.month.split("-").map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    const key = `${d.getFullYear()}-${d.getMonth() + 1}`;
    setLoading(true);
    try {
      const res = await fetch(`/api/reports?month=${key}`);
      const data = await res.json();
      if (!res.ok) throw new Error();
      setReport(data);
    } catch {
      toast("error", "রিপোর্ট আনা যায়নি");
    } finally {
      setLoading(false);
    }
  }

  const maxDaily = Math.max(...report.daily.map((d) => d.amount), 1);
  const methodTotal = Object.values(report.byMethod).reduce((a, b) => a + b, 0) || 1;
  const isCurrentMonth =
    report.month === `${new Date().getFullYear()}-${new Date().getMonth() + 1}` ||
    report.month ===
      `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, "0")}`;

  const summary = [
    {
      label: "মোট আয় (জমা)",
      value: taka(report.totalIncome),
      icon: Banknote,
      cls: "bg-brand-100 text-brand-700",
    },
    {
      label: "মোট বিল করা হয়েছে",
      value: taka(report.ordersBilled),
      icon: Receipt,
      cls: "bg-sky-100 text-sky-700",
    },
    {
      label: "নতুন কাজ",
      value: `${toBn(report.ordersCount)}টি`,
      icon: ClipboardList,
      cls: "bg-violet-100 text-violet-700",
    },
    {
      label: "পেমেন্টের সংখ্যা",
      value: `${toBn(report.paymentsCount)}টি`,
      icon: HandCoins,
      cls: "bg-coin-100 text-coin-700",
    },
  ];

  return (
    <div className="space-y-5">
      {/* Month selector */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => shiftMonth(-1)}
            disabled={loading}
            className="rounded-xl border border-ink-200 bg-white p-2 text-ink-600 shadow-sm transition hover:border-ink-300 disabled:opacity-50"
            aria-label="আগের মাস"
          >
            <ChevronLeft className="h-4.5 w-4.5" />
          </button>
          <span className="inline-flex items-center gap-2 rounded-xl border border-ink-200 bg-white px-4 py-2 text-sm font-bold text-ink-900 shadow-sm">
            <CalendarDays className="h-4 w-4 text-brand-600" />
            {report.monthLabel}
          </span>
          <button
            onClick={() => shiftMonth(1)}
            disabled={loading || isCurrentMonth}
            className="rounded-xl border border-ink-200 bg-white p-2 text-ink-600 shadow-sm transition hover:border-ink-300 disabled:opacity-40"
            aria-label="পরের মাস"
          >
            <ChevronRight className="h-4.5 w-4.5" />
          </button>
        </div>
        {loading && <Spinner className="h-5 w-5 text-brand-600" />}
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3.5 xl:grid-cols-4">
        {summary.map((s) => (
          <div
            key={s.label}
            className="rounded-2xl border border-ink-100 bg-cream p-4 shadow-soft sm:p-5"
          >
            <span className={cn("grid h-10 w-10 place-items-center rounded-xl", s.cls)}>
              <s.icon className="h-5 w-5" />
            </span>
            <div className="mt-3 text-lg font-bold text-ink-950 sm:text-xl">{s.value}</div>
            <div className="text-xs font-semibold text-ink-500">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        {/* Daily chart */}
        <div className="rounded-2xl border border-ink-100 bg-cream p-5 shadow-soft sm:p-6 lg:col-span-3">
          <h3 className="flex items-center gap-2 text-[15px] font-bold text-ink-950">
            <ChartColumn className="h-4.5 w-4.5 text-brand-600" />
            দৈনিক আয় — {report.monthLabel}
          </h3>
          <div className="mt-6 flex h-44 items-end gap-[3px]">
            {report.daily.map((d) => (
              <div
                key={d.day}
                className="group relative flex-1"
                title={`${toBn(d.day)} তারিখ — ${taka(d.amount)}`}
              >
                <span className="pointer-events-none absolute -top-3 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-md bg-ink-950 px-1.5 py-0.5 text-[10px] font-bold text-white opacity-0 shadow-lift transition group-hover:-top-6 group-hover:opacity-100">
                  {taka(d.amount)}
                </span>
                <div
                  className={cn(
                    "w-full rounded-t-md transition-all duration-500",
                    d.amount > 0 ? "bg-gradient-to-t from-brand-600/80 to-brand-400 hover:from-brand-600" : "bg-ink-100/70"
                  )}
                  style={{ height: `${Math.max((d.amount / maxDaily) * 168, 3)}px` }}
                />
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[10px] font-semibold text-ink-400">
            <span>{toBn(1)} তারিখ</span>
            <span>{toBn(15)}</span>
            <span>{toBn(report.daily.length)} তারিখ</span>
          </div>

          {/* Payment methods */}
          <div className="mt-6 border-t border-ink-100 pt-5">
            <p className="text-xs font-bold text-ink-500">পেমেন্টের মাধ্যম</p>
            <div className="mt-3 space-y-2.5">
              {Object.entries(report.byMethod).map(([k, v]) => (
                <div key={k} className="flex items-center gap-3">
                  <span className="w-16 text-[12.5px] font-semibold text-ink-600">
                    {METHOD_LABEL[k] ?? k}
                  </span>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-ink-100">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        k === "cash" ? "bg-brand-500" : k === "bkash" ? "bg-pink-500" : "bg-orange-500"
                      )}
                      style={{ width: `${(v / methodTotal) * 100}%` }}
                    />
                  </div>
                  <span className="w-20 text-right text-[12.5px] font-bold text-ink-800">
                    {taka(v)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Ledger */}
        <div className="overflow-hidden rounded-2xl border border-ink-100 bg-cream shadow-soft lg:col-span-2">
          <div className="border-b border-ink-100 px-5 py-4">
            <h3 className="text-[15px] font-bold text-ink-950">লেনদেনের খাতা</h3>
            <p className="text-xs text-ink-400">এই মাসের সব টাকা জমা</p>
          </div>
          {report.ledger.length === 0 ? (
            <EmptyState
              icon={Receipt}
              title="এই মাসে লেনদেন নেই"
              message="কাজের টাকা জমা নিলে এখানে সব লেনদেনের তালিকা দেখা যাবে।"
            />
          ) : (
            <ul className="max-h-[430px] divide-y divide-ink-100/70 overflow-y-auto">
              {report.ledger.map((p) => (
                <li key={p.id} className="flex items-center gap-3 px-5 py-3">
                  <span
                    className={cn(
                      "grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[13px] font-bold",
                      p.method === "bkash"
                        ? "bg-pink-100 text-pink-600"
                        : p.method === "nagad"
                          ? "bg-orange-100 text-orange-600"
                          : "bg-brand-100 text-brand-700"
                    )}
                  >
                    {(METHOD_LABEL[p.method] ?? "ন")[0]}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[13px] font-bold text-ink-900">
                      {p.customerName}
                    </div>
                    <div className="truncate text-[11px] text-ink-400">
                      {p.serviceName} • {orderNo(p.orderId)} • {bnDateTime(p.createdAt)}
                    </div>
                  </div>
                  <span className="text-[13.5px] font-bold text-brand-700">+{taka(p.amount)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
