"use client";

import { useState } from "react";
import {
  Baby,
  BookUser,
  Briefcase,
  Camera,
  Copy,
  FileText,
  Globe,
  IdCard,
  Image as ImageIcon,
  Laptop,
  Layers,
  Mail,
  Package,
  Pencil,
  Plus,
  Printer,
  ScanLine,
  Smartphone,
  Trash2,
  Wifi,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { taka, toBn } from "@/lib/format";
import { ConfirmDialog, EmptyState, Field, inputCls, Modal, Spinner } from "@/components/ui";
import { useToast } from "@/components/toast";
import type { ServiceRow } from "@/lib/queries";

export const SERVICE_ICONS: Record<string, LucideIcon> = {
  briefcase: Briefcase,
  "book-user": BookUser,
  baby: Baby,
  "id-card": IdCard,
  copy: Copy,
  printer: Printer,
  camera: Camera,
  layers: Layers,
  "file-text": FileText,
  smartphone: Smartphone,
  globe: Globe,
  "scan-line": ScanLine,
  image: ImageIcon,
  laptop: Laptop,
  wifi: Wifi,
  mail: Mail,
  package: Package,
};

const COLOR_META: Record<string, { box: string; swatch: string }> = {
  emerald: { box: "bg-brand-100 text-brand-700", swatch: "bg-brand-500" },
  sky: { box: "bg-sky-100 text-sky-700", swatch: "bg-sky-500" },
  amber: { box: "bg-coin-100 text-coin-700", swatch: "bg-coin-500" },
  violet: { box: "bg-violet-100 text-violet-700", swatch: "bg-violet-500" },
  rose: { box: "bg-rose-100 text-rose-600", swatch: "bg-rose-500" },
  slate: { box: "bg-ink-100 text-ink-700", swatch: "bg-ink-500" },
  orange: { box: "bg-orange-100 text-orange-600", swatch: "bg-orange-500" },
  teal: { box: "bg-teal-100 text-teal-700", swatch: "bg-teal-500" },
  indigo: { box: "bg-indigo-100 text-indigo-700", swatch: "bg-indigo-500" },
  pink: { box: "bg-pink-100 text-pink-600", swatch: "bg-pink-500" },
};

type Form = { name: string; description: string; price: string; icon: string; color: string };
const emptyForm: Form = { name: "", description: "", price: "", icon: "file-text", color: "emerald" };

export default function ServicesClient({ initialServices }: { initialServices: ServiceRow[] }) {
  const { toast } = useToast();
  const [items, setItems] = useState<ServiceRow[]>(initialServices);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<ServiceRow | null>(null);
  const [form, setForm] = useState<Form>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ServiceRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setFormOpen(true);
  }

  function openEdit(s: ServiceRow) {
    setEditing(s);
    setForm({
      name: s.name,
      description: s.description ?? "",
      price: String(s.price),
      icon: s.icon,
      color: s.color,
    });
    setFormOpen(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        const res = await fetch(`/api/services/${editing.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...form, price: Number(form.price) || 0 }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setItems((prev) => prev.map((s) => (s.id === editing.id ? { ...s, ...data.service } : s)));
        toast("success", "সার্ভিস আপডেট হয়েছে");
      } else {
        const res = await fetch("/api/services", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...form, price: Number(form.price) || 0 }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setItems((prev) => [...prev, data.service]);
        toast("success", "নতুন সার্ভিস যোগ হয়েছে");
      }
      setFormOpen(false);
      setEditing(null);
    } catch (err) {
      toast("error", err instanceof Error ? err.message : "সমস্যা হয়েছে");
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(s: ServiceRow) {
    const next = !s.active;
    const prev = items;
    setItems((cur) => cur.map((x) => (x.id === s.id ? { ...x, active: next } : x)));
    const res = await fetch(`/api/services/${s.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: next }),
    });
    if (!res.ok) {
      setItems(prev);
      toast("error", "বদলানো যায়নি");
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    const prev = items;
    setItems((cur) => cur.filter((s) => s.id !== deleteTarget.id));
    const res = await fetch(`/api/services/${deleteTarget.id}`, { method: "DELETE" });
    setDeleting(false);
    if (!res.ok) {
      setItems(prev);
      toast("error", "মুছে ফেলা যায়নি");
    } else {
      toast("success", "সার্ভিস মুছে ফেলা হয়েছে");
    }
    setDeleteTarget(null);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-ink-500">
          মোট <span className="font-bold text-ink-900">{toBn(items.length)}টি</span> সার্ভিস •{" "}
          <span className="font-bold text-brand-700">{toBn(items.filter((s) => s.active).length)}টি</span> চালু
        </p>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 active:scale-[0.98]"
        >
          <Plus className="h-4.5 w-4.5" />
          নতুন সার্ভিস
        </button>
      </div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-ink-100 bg-cream shadow-soft">
          <EmptyState
            icon={Package}
            title="কোনো সার্ভিস নেই"
            message="আপনার দোকানের সেবাগুলো যোগ করুন — যেমন পাসপোর্ট আবেদন, ফটোকপি, প্রিন্ট ইত্যাদি।"
            actionLabel="সার্ভিস যোগ করুন"
            onAction={openCreate}
          />
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((s) => {
            const Icon = SERVICE_ICONS[s.icon] ?? FileText;
            const color = COLOR_META[s.color] ?? COLOR_META.emerald;
            return (
              <div
                key={s.id}
                className={cn(
                  "group relative overflow-hidden rounded-2xl border border-ink-100 bg-cream p-5 shadow-soft transition hover:shadow-lift",
                  !s.active && "opacity-60"
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <span className={cn("grid h-12 w-12 place-items-center rounded-2xl", color.box)}>
                    <Icon className="h-6 w-6" />
                  </span>
                  <button
                    onClick={() => toggleActive(s)}
                    title={s.active ? "বন্ধ করুন" : "চালু করুন"}
                    className={cn(
                      "relative h-6 w-11 rounded-full transition-colors",
                      s.active ? "bg-brand-500" : "bg-ink-200"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
                        s.active ? "left-[22px]" : "left-0.5"
                      )}
                    />
                  </button>
                </div>

                <h3 className="mt-3.5 text-[15px] font-bold text-ink-950">{s.name}</h3>
                {s.description && (
                  <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-ink-500">
                    {s.description}
                  </p>
                )}

                <div className="mt-4 flex items-end justify-between border-t border-ink-100 pt-3.5">
                  <div>
                    <div className="text-lg font-bold text-ink-950">{taka(s.price)}</div>
                    <div className="text-[11px] text-ink-400">
                      {toBn(s.ordersCount)}টি কাজ • আয় {taka(s.revenue)}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => openEdit(s)}
                      className="rounded-lg p-2 text-ink-400 transition hover:bg-ink-100 hover:text-ink-800"
                      title="সম্পাদনা"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setDeleteTarget(s)}
                      className="rounded-lg p-2 text-ink-300 transition hover:bg-red-50 hover:text-red-600"
                      title="মুছুন"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        title={editing ? "সার্ভিস সম্পাদনা" : "নতুন সার্ভিস যোগ করুন"}
      >
        <form onSubmit={submit} className="space-y-4">
          <Field label="সার্ভিসের নাম">
            <input
              className={inputCls}
              placeholder="যেমন: পাসপোর্ট আবেদন"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </Field>
          <Field label="বিবরণ" optional>
            <input
              className={inputCls}
              placeholder="সংক্ষিপ্ত বিবরণ…"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </Field>
          <Field label="মূল্য (৳)">
            <input
              type="number"
              min={0}
              className={inputCls}
              placeholder="0"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              required
            />
          </Field>

          <Field label="আইকন">
            <div className="grid grid-cols-8 gap-1.5">
              {Object.entries(SERVICE_ICONS).map(([key, Icon]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setForm({ ...form, icon: key })}
                  className={cn(
                    "grid aspect-square place-items-center rounded-xl border transition",
                    form.icon === key
                      ? "border-brand-500 bg-brand-50 text-brand-700 ring-2 ring-brand-500/20"
                      : "border-ink-200 bg-white text-ink-400 hover:border-ink-300 hover:text-ink-700"
                  )}
                >
                  <Icon className="h-4.5 w-4.5" />
                </button>
              ))}
            </div>
          </Field>

          <Field label="রং">
            <div className="flex flex-wrap gap-2">
              {Object.entries(COLOR_META).map(([key, c]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setForm({ ...form, color: key })}
                  className={cn(
                    "h-8 w-8 rounded-full transition",
                    c.swatch,
                    form.color === key ? "ring-2 ring-ink-950 ring-offset-2" : "hover:scale-110"
                  )}
                  title={key}
                />
              ))}
            </div>
          </Field>

          <div className="flex justify-end gap-2.5 border-t border-ink-100 pt-4">
            <button
              type="button"
              onClick={() => {
                setFormOpen(false);
                setEditing(null);
              }}
              className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 disabled:opacity-60"
            >
              {saving && <Spinner className="h-4 w-4" />}
              {editing ? "সংরক্ষণ করুন" : "যোগ করুন"}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        busy={deleting}
        title="সার্ভিস মুছে ফেলবেন?"
        message={
          deleteTarget
            ? `“${deleteTarget.name}” সার্ভিসটি মুছে যাবে। আগের অর্ডারগুলোতে নামটি সংরক্ষিত থাকবে।`
            : ""
        }
      />
    </div>
  );
}
