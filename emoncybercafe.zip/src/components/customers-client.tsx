"use client";

import { useMemo, useState } from "react";
import { MapPin, Pencil, Phone, Plus, Search, Trash2, UserRound, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { bnDateShort, taka, toBn } from "@/lib/format";
import {
  Avatar,
  ConfirmDialog,
  EmptyState,
  Field,
  inputCls,
  Modal,
  Spinner,
} from "@/components/ui";
import { useToast } from "@/components/toast";
import type { CustomerRow } from "@/lib/queries";

type Form = { name: string; phone: string; email: string; address: string; note: string };
const emptyForm: Form = { name: "", phone: "", email: "", address: "", note: "" };

export default function CustomersClient({ initialCustomers }: { initialCustomers: CustomerRow[] }) {
  const { toast } = useToast();
  const [items, setItems] = useState<CustomerRow[]>(initialCustomers);
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<CustomerRow | null>(null);
  const [form, setForm] = useState<Form>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<CustomerRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (c.address ?? "").toLowerCase().includes(q)
    );
  }, [items, search]);

  const totalDue = items.reduce((s, c) => s + c.totalDue, 0);
  const activeCustomers = items.filter((c) => c.ordersCount > 0).length;

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setFormOpen(true);
  }

  function openEdit(c: CustomerRow) {
    setEditing(c);
    setForm({
      name: c.name,
      phone: c.phone,
      email: c.email ?? "",
      address: c.address ?? "",
      note: c.note ?? "",
    });
    setFormOpen(true);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        const res = await fetch(`/api/customers/${editing.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setItems((prev) =>
          prev.map((c) => (c.id === editing.id ? { ...c, ...data.customer } : c))
        );
        toast("success", "গ্রাহকের তথ্য আপডেট হয়েছে");
      } else {
        const res = await fetch("/api/customers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setItems((prev) => [data.customer, ...prev]);
        toast("success", "নতুন গ্রাহক যোগ হয়েছে");
      }
      setFormOpen(false);
      setEditing(null);
    } catch (err) {
      toast("error", err instanceof Error ? err.message : "সমস্যা হয়েছে");
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    const prev = items;
    setItems((cur) => cur.filter((c) => c.id !== deleteTarget.id));
    const res = await fetch(`/api/customers/${deleteTarget.id}`, { method: "DELETE" });
    setDeleting(false);
    if (!res.ok) {
      setItems(prev);
      toast("error", "মুছে ফেলা যায়নি");
    } else {
      toast("success", "গ্রাহক মুছে ফেলা হয়েছে");
    }
    setDeleteTarget(null);
  }

  const chips = [
    { label: "মোট গ্রাহক", value: toBn(items.length) },
    { label: "কাজ নেওয়া গ্রাহক", value: toBn(activeCustomers) },
    { label: "মোট বাকি", value: taka(totalDue), danger: totalDue > 0 },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="নাম, ফোন বা ঠিকানা দিয়ে খুঁজুন…"
            className={cn(inputCls, "pl-10")}
          />
        </div>
        <button
          onClick={openCreate}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 active:scale-[0.98]"
        >
          <Plus className="h-4.5 w-4.5" />
          নতুন গ্রাহক
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {chips.map((c) => (
          <span
            key={c.label}
            className="inline-flex items-center gap-2 rounded-full border border-ink-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-ink-600 shadow-sm"
          >
            {c.label}
            <span className={cn("font-bold", c.danger ? "text-rose-600" : "text-ink-950")}>
              {c.value}
            </span>
          </span>
        ))}
      </div>

      <div className="overflow-hidden rounded-2xl border border-ink-100 bg-cream shadow-soft">
        {items.length === 0 ? (
          <EmptyState
            icon={Users}
            title="এখনো কোনো গ্রাহক নেই"
            message="আপনার প্রথম গ্রাহক যোগ করুন — নাম ও ফোন নম্বর দিলেই শুরু। পরে কাজের হিসাব স্বয়ংক্রিয়ভাবে যুক্ত হবে।"
            actionLabel="গ্রাহক যোগ করুন"
            onAction={openCreate}
          />
        ) : filtered.length === 0 ? (
          <EmptyState icon={Search} title="কাউকে পাওয়া যায়নি" message="অন্য নাম বা ফোন নম্বর দিয়ে চেষ্টা করুন।" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left">
              <thead>
                <tr className="border-b border-ink-100 text-[11.5px] font-bold uppercase tracking-wide text-ink-400">
                  <th className="px-5 py-3.5">গ্রাহক</th>
                  <th className="px-4 py-3.5">যোগাযোগ</th>
                  <th className="px-4 py-3.5 text-center">মোট কাজ</th>
                  <th className="px-4 py-3.5 text-right">মোট বিল</th>
                  <th className="px-4 py-3.5 text-right">বাকি</th>
                  <th className="px-4 py-3.5 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100/70">
                {filtered.map((c) => (
                  <tr key={c.id} className="transition-colors hover:bg-white/80">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <Avatar name={c.name} />
                        <div className="min-w-0">
                          <div className="truncate text-[14px] font-bold text-ink-900">{c.name}</div>
                          {c.address && (
                            <div className="flex items-center gap-1 truncate text-[11.5px] text-ink-400">
                              <MapPin className="h-3 w-3 shrink-0" />
                              {c.address}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5 text-[13px] font-semibold text-ink-700">
                        <Phone className="h-3.5 w-3.5 text-ink-300" />
                        {c.phone}
                      </div>
                      <div className="mt-0.5 text-[11px] text-ink-400">
                        যুক্ত {bnDateShort(c.createdAt)}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="inline-flex min-w-8 items-center justify-center rounded-full bg-ink-100/70 px-2.5 py-1 text-xs font-bold text-ink-700">
                        {toBn(c.ordersCount)}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-right text-[13.5px] font-bold text-ink-900">
                      {taka(c.totalBilled)}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <span
                        className={cn(
                          "text-[13.5px] font-bold",
                          c.totalDue > 0 ? "text-rose-600" : "text-brand-600"
                        )}
                      >
                        {c.totalDue > 0 ? taka(c.totalDue) : "নেই"}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => openEdit(c)}
                          title="সম্পাদনা"
                          className="rounded-lg p-2 text-ink-400 transition hover:bg-ink-100 hover:text-ink-800"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget(c)}
                          title="মুছুন"
                          className="rounded-lg p-2 text-ink-300 transition hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        title={editing ? "গ্রাহকের তথ্য সম্পাদনা" : "নতুন গ্রাহক যোগ করুন"}
      >
        <form onSubmit={submit} className="space-y-4">
          <Field label="গ্রাহকের নাম">
            <input
              className={inputCls}
              placeholder="যেমন: মোঃ রহিম উদ্দিন"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="ফোন নম্বর">
              <input
                className={inputCls}
                placeholder="01XXXXXXXXX"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                required
              />
            </Field>
            <Field label="ইমেইল" optional>
              <input
                type="email"
                className={inputCls}
                placeholder="email@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </Field>
          </div>
          <Field label="ঠিকানা" optional>
            <input
              className={inputCls}
              placeholder="গ্রাম/এলাকা, থানা, জেলা"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
            />
          </Field>
          <Field label="নোট" optional>
            <textarea
              rows={2}
              className={cn(inputCls, "resize-none")}
              placeholder="বিশেষ কিছু মনে রাখার থাকলে…"
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
            />
          </Field>
          <div className="flex justify-end gap-2.5 border-t border-ink-100 pt-4">
            <button
              type="button"
              onClick={() => {
                setFormOpen(false);
                setEditing(null);
              }}
              className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 disabled:opacity-60"
            >
              {saving && <Spinner className="h-4 w-4" />}
              <UserRound className="h-4 w-4" />
              {editing ? "সংরক্ষণ করুন" : "গ্রাহক যোগ করুন"}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        busy={deleting}
        title="গ্রাহক মুছে ফেলবেন?"
        message={
          deleteTarget
            ? `“${deleteTarget.name}” এবং তার সব কাজ ও পেমেন্টের হিসাব স্থায়ীভাবে মুছে যাবে।`
            : ""
        }
      />
    </div>
  );
}
