"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Eye, EyeOff, Loader2, Lock, Mail, User } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AuthForm() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "কিছু একটা সমস্যা হয়েছে");
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("নেটওয়ার্ক সমস্যা, আবার চেষ্টা করুন");
    } finally {
      setLoading(false);
    }
  }

  const inputCls =
    "w-full rounded-xl border border-ink-200 bg-white px-4 py-3 pl-11 text-[15px] text-ink-900 placeholder:text-ink-300 shadow-sm outline-none transition focus:border-brand-500 focus:ring-4 focus:ring-brand-500/15";

  return (
    <div className="w-full max-w-md animate-fade-up">
      {/* mobile brand */}
      <div className="mb-8 flex items-center gap-3 lg:hidden">
        <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-700 text-xl font-bold text-white">
          ই
        </div>
        <div>
          <div className="font-bold leading-tight">ইমন সাইবার ক্যাফে</div>
          <div className="text-xs text-ink-500">দোকান ব্যবস্থাপনা</div>
        </div>
      </div>

      <div className="rounded-3xl border border-ink-100 bg-cream p-7 shadow-lift sm:p-9">
        <h2 className="text-2xl font-bold text-ink-950">
          {mode === "login" ? "স্বাগতম!" : "নতুন অ্যাকাউন্ট"}
        </h2>
        <p className="mt-1 text-sm text-ink-500">
          {mode === "login"
            ? "আপনার দোকানে লগইন করুন"
            : "মিনিটেই আপনার দোকান শুরু করুন"}
        </p>

        {/* mode switch */}
        <div className="mt-6 grid grid-cols-2 gap-1 rounded-xl bg-ink-100/70 p-1">
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setMode(m);
                setError("");
              }}
              className={cn(
                "rounded-lg py-2 text-sm font-semibold transition-all",
                mode === m
                  ? "bg-white text-ink-950 shadow-soft"
                  : "text-ink-500 hover:text-ink-800"
              )}
            >
              {m === "login" ? "লগইন" : "নিবন্ধন"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "register" && (
            <div className="relative">
              <User className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-400" />
              <input
                className={inputCls}
                placeholder="আপনার নাম"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
          )}
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-400" />
            <input
              type="email"
              className={inputCls}
              placeholder="ইমেইল ঠিকানা"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-ink-400" />
            <input
              type={showPass ? "text" : "password"}
              className={cn(inputCls, "pr-11")}
              placeholder={mode === "register" ? "পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)" : "পাসওয়ার্ড"}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              minLength={mode === "register" ? 6 : undefined}
              required
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-ink-400 hover:text-ink-700"
              aria-label="পাসওয়ার্ড দেখুন"
            >
              {showPass ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
            </button>
          </div>

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm font-medium text-red-700 animate-fade-in">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="group flex w-full items-center justify-center gap-2 rounded-xl bg-ink-950 py-3.5 text-[15px] font-bold text-white shadow-lift transition hover:bg-ink-800 active:scale-[0.99] disabled:opacity-60"
          >
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                {mode === "login" ? "লগইন করুন" : "অ্যাকাউন্ট খুলুন"}
                <ArrowRight className="h-4.5 w-4.5 transition-transform group-hover:translate-x-1" />
              </>
            )}
          </button>
        </form>

      </div>

      <p className="mt-6 text-center text-xs text-ink-400">
        আপনার তথ্য সম্পূর্ণ নিরাপদ — কারো সাথে শেয়ার করা হয় না।
      </p>
    </div>
  );
}
