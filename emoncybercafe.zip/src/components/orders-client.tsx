"use client";

import { useMemo, useState } from "react";
import {
  Banknote,
  CalendarClock,
  ClipboardList,
  HandCoins,
  Loader2,
  Pencil,
  Plus,
  Search,
  Trash2,
  UserPlus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { bnDate, orderNo, STATUS_META, taka, toBn } from "@/lib/format";
import {
  Avatar,
  ConfirmDialog,
  EmptyState,
  Field,
  inputCls,
  Modal,
  Spinner,
} from "@/components/ui";
import { useToast } from "@/components/toast";
import type { CustomerRow, OrderRow, ServiceRow } from "@/lib/queries";

const STATUS_ORDER = ["pending", "in_progress", "completed", "delivered"] as const;

type Props = {
  initialOrders: OrderRow[];
  customers: CustomerRow[];
  services: ServiceRow[];
  openNew: boolean;
};

type OrderForm = {
  customerId: number | "";
  newCustomer: boolean;
  newName: string;
  newPhone: string;
  serviceId: number | "";
  quantity: number;
  totalAmount: string;
  paidAmount: string;
  status: string;
  deliveryDate: string;
  note: string;
};

const emptyForm: OrderForm = {
  customerId: "",
  newCustomer: false,
  newName: "",
  newPhone: "",
  serviceId: "",
  quantity: 1,
  totalAmount: "",
  paidAmount: "",
  status: "pending",
  deliveryDate: "",
  note: "",
};

function toDateInput(d: string | Date | null): string {
  if (!d) return "";
  const date = new Date(d);
  if (isNaN(date.getTime())) return "";
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function OrdersClient({ initialOrders, customers, services, openNew }: Props) {
  const { toast } = useToast();
  const [orders, setOrders] = useState<OrderRow[]>(initialOrders);
  const [customerList, setCustomerList] = useState<CustomerRow[]>(customers);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(openNew);
  const [editing, setEditing] = useState<OrderRow | null>(null);
  const [form, setForm] = useState<OrderForm>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [payTarget, setPayTarget] = useState<OrderRow | null>(null);
  const [payForm, setPayForm] = useState({ amount: "", method: "cash", note: "" });
  const [payBusy, setPayBusy] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<OrderRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: orders.length };
    for (const s of STATUS_ORDER) c[s] = orders.filter((o) => o.status === s).length;
    return c;
  }, [orders]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return orders.filter((o) => {
      if (statusFilter !== "all" && o.status !== statusFilter) return false;
      if (!q) return true;
      return (
        o.customer.name.toLowerCase().includes(q) ||
        o.customer.phone.includes(q) ||
        o.serviceName.toLowerCase().includes(q) ||
        orderNo(o.id).includes(search.trim().replace("#", ""))
      );
    });
  }, [orders, statusFilter, search]);

  /* ------------------------------ form logic ------------------------------ */

  function openCreate() {
    setEditing(null);
    setForm({ ...emptyForm, customerId: customerList[0]?.id ?? "" });
    setFormOpen(true);
  }

  function openEdit(o: OrderRow) {
    setEditing(o);
    setForm({
      customerId: o.customer.id,
      newCustomer: false,
      newName: "",
      newPhone: "",
      serviceId: o.serviceId ?? "",
      quantity: o.quantity,
      totalAmount: String(o.totalAmount),
      paidAmount: String(o.paidAmount),
      status: o.status,
      deliveryDate: toDateInput(o.deliveryDate),
      note: o.note ?? "",
    });
    setFormOpen(true);
  }

  function selectService(id: number | "") {
    const svc = services.find((s) => s.id === id);
    setForm((f) => ({
      ...f,
      serviceId: id,
      totalAmount: svc ? String(svc.price * f.quantity) : f.totalAmount,
    }));
  }

  function changeQuantity(q: number) {
    const qty = Math.max(1, Math.round(q || 1));
    const svc = services.find((s) => s.id === form.serviceId);
    setForm((f) => ({
      ...f,
      quantity: qty,
      totalAmount: svc ? String(svc.price * qty) : f.totalAmount,
    }));
  }

  async function submitForm(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      let customerId = form.customerId;

      if (!editing && form.newCustomer) {
        if (!form.newName.trim() || !form.newPhone.trim()) {
          toast("error", "নতুন গ্রাহকের নাম ও ফোন দিন");
          setSaving(false);
          return;
        }
        const res = await fetch("/api/customers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: form.newName, phone: form.newPhone }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setCustomerList((prev) => [data.customer, ...prev]);
        customerId = data.customer.id;
      }

      if (!customerId) {
        toast("error", "গ্রাহক নির্বাচন করুন");
        setSaving(false);
        return;
      }

      if (editing) {
        const res = await fetch(`/api/orders/${editing.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            status: form.status,
            quantity: form.quantity,
            totalAmount: form.totalAmount,
            paidAmount: form.paidAmount,
            deliveryDate: form.deliveryDate || null,
            note: form.note,
            serviceName: services.find((s) => s.id === form.serviceId)?.name,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setOrders((prev) =>
          prev.map((o) => (o.id === editing.id ? { ...o, ...data.order, customer: o.customer, serviceIcon: o.serviceIcon } : o))
        );
        toast("success", "কাজটি আপডেট হয়েছে");
      } else {
        const res = await fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            customerId,
            serviceId: form.serviceId || undefined,
            quantity: form.quantity,
            totalAmount: form.totalAmount,
            paidAmount: form.paidAmount || 0,
            status: form.status,
            deliveryDate: form.deliveryDate || undefined,
            note: form.note,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        const svc = services.find((s) => s.id === form.serviceId);
        setOrders((prev) => [{ ...data.order, serviceIcon: svc?.icon ?? null }, ...prev]);
        toast("success", "নতুন কাজ যোগ হয়েছে");
      }
      setFormOpen(false);
      setEditing(null);
    } catch (err) {
      toast("error", err instanceof Error ? err.message : "সমস্যা হয়েছে");
    } finally {
      setSaving(false);
    }
  }

  /* --------------------------- status / payment --------------------------- */

  async function changeStatus(order: OrderRow, status: string) {
    const prev = orders;
    setOrders((cur) => cur.map((o) => (o.id === order.id ? { ...o, status } : o)));
    const res = await fetch(`/api/orders/${order.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) {
      setOrders(prev);
      toast("error", "অবস্থা বদলানো যায়নি");
    } else {
      toast("success", `${STATUS_META[status]?.label} - এ স্থানান্তরিত`);
    }
  }

  function openPay(o: OrderRow) {
    setPayTarget(o);
    setPayForm({ amount: String(Math.max(0, o.totalAmount - o.paidAmount)), method: "cash", note: "" });
  }

  async function submitPay(e: React.FormEvent) {
    e.preventDefault();
    if (!payTarget) return;
    setPayBusy(true);
    try {
      const res = await fetch(`/api/orders/${payTarget.id}/payments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payForm),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setOrders((prev) =>
        prev.map((o) => (o.id === payTarget.id ? { ...o, ...data.order, customer: o.customer, serviceIcon: o.serviceIcon } : o))
      );
      toast("success", `${taka(data.payment.amount)} জমা নেওয়া হলো`);
      setPayTarget(null);
    } catch (err) {
      toast("error", err instanceof Error ? err.message : "সমস্যা হয়েছে");
    } finally {
      setPayBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    const prev = orders;
    setOrders((cur) => cur.filter((o) => o.id !== deleteTarget.id));
    const res = await fetch(`/api/orders/${deleteTarget.id}`, { method: "DELETE" });
    setDeleting(false);
    if (!res.ok) {
      setOrders(prev);
      toast("error", "মুছে ফেলা যায়নি");
    } else {
      toast("success", "কাজটি মুছে ফেলা হয়েছে");
    }
    setDeleteTarget(null);
  }

  /* ---------------------------------- UI ---------------------------------- */

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="গ্রাহক, ফোন বা কাজের নাম দিয়ে খুঁজুন…"
            className={cn(inputCls, "pl-10")}
          />
        </div>
        <button
          onClick={openCreate}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 active:scale-[0.98]"
        >
          <Plus className="h-4.5 w-4.5" />
          নতুন কাজ
        </button>
      </div>

      {/* Status tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {[{ k: "all", label: "সব কাজ" }, ...STATUS_ORDER.map((s) => ({ k: s, label: STATUS_META[s].label }))].map(
          (t) => (
            <button
              key={t.k}
              onClick={() => setStatusFilter(t.k)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-[13px] font-bold transition",
                statusFilter === t.k
                  ? "bg-ink-950 text-white shadow-lift"
                  : "border border-ink-200 bg-white text-ink-600 hover:border-ink-300"
              )}
            >
              {t.k !== "all" && (
                <span
                  className={cn(
                    "h-2 w-2 rounded-full",
                    statusFilter === t.k ? "bg-white" : STATUS_META[t.k].dot
                  )}
                />
              )}
              {t.label}
              <span
                className={cn(
                  "rounded-full px-1.5 py-0.5 text-[11px] leading-none",
                  statusFilter === t.k ? "bg-white/20" : "bg-ink-100"
                )}
              >
                {toBn(counts[t.k] ?? 0)}
              </span>
            </button>
          )
        )}
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-ink-100 bg-cream shadow-soft">
        {orders.length === 0 ? (
          <EmptyState
            icon={ClipboardList}
            title="এখনো কোনো কাজ নেই"
            message="প্রথম কাজটি যোগ করুন — গ্রাহক, কাজের ধরন, টাকার পরিমাণ ও অগ্রিম জমা দিলেই সব হিসাব তৈরি হয়ে যাবে।"
            actionLabel="নতুন কাজ যোগ করুন"
            onAction={openCreate}
          />
        ) : filtered.length === 0 ? (
          <EmptyState icon={Search} title="কিছু পাওয়া যায়নি" message="অন্য কিছু লিখে খুঁজে দেখুন অথবা ফিল্টার বদলান।" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left">
              <thead>
                <tr className="border-b border-ink-100 text-[11.5px] font-bold uppercase tracking-wide text-ink-400">
                  <th className="px-5 py-3.5">অর্ডার</th>
                  <th className="px-4 py-3.5">গ্রাহক</th>
                  <th className="px-4 py-3.5">কাজ</th>
                  <th className="px-4 py-3.5 text-right">টাকা</th>
                  <th className="px-4 py-3.5">অবস্থা</th>
                  <th className="px-4 py-3.5 text-right">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100/70">
                {filtered.map((o) => {
                  const due = o.totalAmount - o.paidAmount;
                  return (
                    <tr key={o.id} className="group transition-colors hover:bg-white/80">
                      <td className="px-5 py-3.5 align-top">
                        <div className="font-mono text-[13px] font-bold text-ink-900">{orderNo(o.id)}</div>
                        <div className="mt-0.5 whitespace-nowrap text-[11.5px] text-ink-400">
                          {bnDate(o.createdAt)}
                        </div>
                        {o.deliveryDate && (
                          <div className="mt-1 inline-flex items-center gap-1 rounded-md bg-coin-50 px-1.5 py-0.5 text-[10.5px] font-bold text-coin-700 ring-1 ring-inset ring-coin-200">
                            <CalendarClock className="h-3 w-3" />
                            {bnDate(o.deliveryDate)}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3.5 align-top">
                        <div className="flex items-center gap-2.5">
                          <Avatar name={o.customer.name} className="h-9 w-9 text-sm" />
                          <div className="min-w-0">
                            <div className="truncate text-[13.5px] font-bold text-ink-900">
                              {o.customer.name}
                            </div>
                            <div className="text-[11.5px] text-ink-400">{o.customer.phone}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 align-top">
                        <div className="text-[13.5px] font-semibold text-ink-800">
                          {o.serviceName}
                          {o.quantity > 1 && (
                            <span className="text-ink-400"> × {toBn(o.quantity)}</span>
                          )}
                        </div>
                        {o.note && <div className="mt-0.5 max-w-52 truncate text-[11.5px] text-ink-400">{o.note}</div>}
                      </td>
                      <td className="px-4 py-3.5 text-right align-top">
                        <div className="text-[14px] font-bold text-ink-950">{taka(o.totalAmount)}</div>
                        <div className="text-[11px] font-medium text-ink-400">
                          জমা {taka(o.paidAmount)}
                        </div>
                        <div
                          className={cn(
                            "text-[11.5px] font-bold",
                            due > 0 ? "text-rose-600" : "text-brand-600"
                          )}
                        >
                          {due > 0 ? `বাকি ${taka(due)}` : "পরিশোধিত"}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 align-top">
                        <div className="relative inline-block">
                          <span
                            className={cn(
                              "pointer-events-none absolute left-2.5 top-1/2 h-2 w-2 -translate-y-1/2 rounded-full",
                              STATUS_META[o.status]?.dot
                            )}
                          />
                          <select
                            value={o.status}
                            onChange={(e) => changeStatus(o, e.target.value)}
                            className={cn(
                              "cursor-pointer appearance-none rounded-full py-1.5 pl-7 pr-3 text-xs font-bold ring-1 ring-inset outline-none transition focus:ring-2",
                              STATUS_META[o.status]?.badge
                            )}
                          >
                            {STATUS_ORDER.map((s) => (
                              <option key={s} value={s}>
                                {STATUS_META[s].label}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-right align-top">
                        <div className="inline-flex items-center gap-1">
                          {due > 0 && (
                            <button
                              onClick={() => openPay(o)}
                              title="টাকা জমা নিন"
                              className="rounded-lg p-2 text-brand-600 transition hover:bg-brand-50"
                            >
                              <HandCoins className="h-4.5 w-4.5" />
                            </button>
                          )}
                          <button
                            onClick={() => openEdit(o)}
                            title="সম্পাদনা"
                            className="rounded-lg p-2 text-ink-400 transition hover:bg-ink-100 hover:text-ink-800"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => setDeleteTarget(o)}
                            title="মুছুন"
                            className="rounded-lg p-2 text-ink-300 transition hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ------------------------- Create / Edit modal ------------------------ */}
      <Modal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        title={editing ? `কাজ সম্পাদনা — ${orderNo(editing.id)}` : "নতুন কাজ যোগ করুন"}
        subtitle={editing ? undefined : "গ্রাহক, কাজ ও টাকার তথ্য দিন"}
        wide
      >
        <form onSubmit={submitForm} className="space-y-4">
          {/* customer */}
          {editing ? (
            <Field label="গ্রাহক">
              <div className="flex items-center gap-2.5 rounded-xl border border-ink-200 bg-ink-50/60 px-3.5 py-2.5">
                <Avatar name={editing.customer.name} className="h-7 w-7 text-xs" />
                <span className="text-sm font-semibold text-ink-800">{editing.customer.name}</span>
              </div>
            </Field>
          ) : (
            <Field label="গ্রাহক">
              {!form.newCustomer ? (
                <div className="flex gap-2">
                  <select
                    className={inputCls}
                    value={form.customerId}
                    onChange={(e) => setForm({ ...form, customerId: Number(e.target.value) })}
                    required={!form.newCustomer}
                  >
                    <option value="" disabled>
                      গ্রাহক নির্বাচন করুন
                    </option>
                    {customerList.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} — {c.phone}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, newCustomer: true })}
                    title="নতুন গ্রাহক"
                    className="grid w-11 shrink-0 place-items-center rounded-xl border border-dashed border-brand-400 bg-brand-50 text-brand-700 transition hover:bg-brand-100"
                  >
                    <UserPlus className="h-4.5 w-4.5" />
                  </button>
                </div>
              ) : (
                <div className="space-y-2 rounded-xl border border-dashed border-brand-300 bg-brand-50/50 p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-brand-800">নতুন গ্রাহক</span>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, newCustomer: false })}
                      className="text-xs font-semibold text-ink-500 underline"
                    >
                      তালিকা থেকে নিন
                    </button>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <input
                      className={inputCls}
                      placeholder="গ্রাহকের নাম"
                      value={form.newName}
                      onChange={(e) => setForm({ ...form, newName: e.target.value })}
                    />
                    <input
                      className={inputCls}
                      placeholder="ফোন নম্বর"
                      value={form.newPhone}
                      onChange={(e) => setForm({ ...form, newPhone: e.target.value })}
                    />
                  </div>
                </div>
              )}
            </Field>
          )}

          <div className="grid gap-4 sm:grid-cols-[1fr_120px]">
            <Field label="কাজ / সার্ভিস">
              <select
                className={inputCls}
                value={form.serviceId}
                onChange={(e) => selectService(e.target.value ? Number(e.target.value) : "")}
              >
                <option value="">সাধারণ সার্ভিস</option>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} — {taka(s.price)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="পরিমাণ">
              <input
                type="number"
                min={1}
                className={inputCls}
                value={form.quantity}
                onChange={(e) => changeQuantity(Number(e.target.value))}
              />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="মোট টাকা (৳)">
              <input
                type="number"
                min={0}
                className={inputCls}
                placeholder="0"
                value={form.totalAmount}
                onChange={(e) => setForm({ ...form, totalAmount: e.target.value })}
                required
              />
            </Field>
            <Field
              label={editing ? "মোট জমা (৳)" : "অগ্রিম জমা (৳)"}
              optional
            >
              <input
                type="number"
                min={0}
                className={inputCls}
                placeholder="0"
                value={form.paidAmount}
                onChange={(e) => setForm({ ...form, paidAmount: e.target.value })}
              />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="কাজের অবস্থা">
              <select
                className={inputCls}
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                {STATUS_ORDER.map((s) => (
                  <option key={s} value={s}>
                    {STATUS_META[s].label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="ডেলিভারির তারিখ" optional>
              <input
                type="date"
                className={inputCls}
                value={form.deliveryDate}
                onChange={(e) => setForm({ ...form, deliveryDate: e.target.value })}
              />
            </Field>
          </div>

          <Field label="নোট" optional>
            <textarea
              rows={2}
              className={cn(inputCls, "resize-none")}
              placeholder="যেমন: পাসপোর্টের রশিদ নম্বর, বিশেষ নির্দেশনা…"
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
            />
          </Field>

          <div className="flex items-center justify-end gap-2.5 border-t border-ink-100 pt-4">
            <button
              type="button"
              onClick={() => {
                setFormOpen(false);
                setEditing(null);
              }}
              className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition hover:bg-ink-50"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-xl bg-ink-950 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-ink-800 disabled:opacity-60"
            >
              {saving && <Spinner className="h-4 w-4" />}
              {editing ? "সংরক্ষণ করুন" : "কাজ যোগ করুন"}
            </button>
          </div>
        </form>
      </Modal>

      {/* ----------------------------- Pay modal ------------------------------ */}
      <Modal
        open={!!payTarget}
        onClose={() => setPayTarget(null)}
        title="টাকা জমা নিন"
        subtitle={
          payTarget
            ? `${payTarget.customer.name} — ${payTarget.serviceName} (${orderNo(payTarget.id)})`
            : undefined
        }
      >
        {payTarget && (
          <form onSubmit={submitPay} className="space-y-4">
            <div className="flex items-center justify-between rounded-2xl bg-ink-50/70 px-4 py-3 text-sm">
              <span className="text-ink-500">বাকি আছে</span>
              <span className="text-lg font-bold text-rose-600">
                {taka(Math.max(0, payTarget.totalAmount - payTarget.paidAmount))}
              </span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="জমার পরিমাণ (৳)">
                <input
                  type="number"
                  min={1}
                  className={inputCls}
                  value={payForm.amount}
                  onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })}
                  required
                  autoFocus
                />
              </Field>
              <Field label="মাধ্যম">
                <select
                  className={inputCls}
                  value={payForm.method}
                  onChange={(e) => setPayForm({ ...payForm, method: e.target.value })}
                >
                  <option value="cash">নগদ</option>
                  <option value="bkash">বিকাশ</option>
                  <option value="nagad">নগদ অ্যাপ</option>
                </select>
              </Field>
            </div>
            <Field label="নোট" optional>
              <input
                className={inputCls}
                placeholder="যেমন: বাকির টাকা"
                value={payForm.note}
                onChange={(e) => setPayForm({ ...payForm, note: e.target.value })}
              />
            </Field>
            <div className="flex justify-end gap-2.5 border-t border-ink-100 pt-4">
              <button
                type="button"
                onClick={() => setPayTarget(null)}
                className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 hover:bg-ink-50"
              >
                বাতিল
              </button>
              <button
                type="submit"
                disabled={payBusy}
                className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white shadow-lift transition hover:bg-brand-700 disabled:opacity-60"
              >
                {payBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Banknote className="h-4 w-4" />}
                জমা নিন
              </button>
            </div>
          </form>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        busy={deleting}
        title="কাজটি মুছে ফেলবেন?"
        message={
          deleteTarget
            ? `${deleteTarget.customer.name}-এর “${deleteTarget.serviceName}” (${orderNo(deleteTarget.id)}) কাজটি ও তার পেমেন্টের হিসাব স্থায়ীভাবে মুছে যাবে।`
            : ""
        }
      />
    </div>
  );
}
