/** Default service catalog every new shop starts with */
export const DEFAULT_SERVICES: Array<{
  name: string;
  description: string;
  price: number;
  icon: string;
  color: string;
}> = [
  {
    name: "চাকরির আবেদন (অনলাইন)",
    description: "সরকারি/বেসরকারি চাকরির অনলাইন ফরম পূরণ ও জমা",
    price: 100,
    icon: "briefcase",
    color: "emerald",
  },
  {
    name: "পাসপোর্ট আবেদন",
    description: "নতুন পাসপোর্ট / রিনিউ অনলাইন আবেদন ও অ্যাপয়েন্টমেন্ট",
    price: 300,
    icon: "book-user",
    color: "sky",
  },
  {
    name: "জন্ম নিবন্ধন",
    description: "জন্ম নিবন্ধন আবেদন, সংশোধন ও কপি ডাউনলোড",
    price: 100,
    icon: "baby",
    color: "amber",
  },
  {
    name: "এনআইডি (NID) সেবা",
    description: "নতুন ভোটার নিবন্ধন, তথ্য সংশোধন, ডাউনলোড",
    price: 200,
    icon: "id-card",
    color: "violet",
  },
  {
    name: "ফটোকপি (প্রতি পাতা)",
    description: "সাদা-কালো / রঙিন ফটোকপি",
    price: 5,
    icon: "copy",
    color: "slate",
  },
  {
    name: "কম্পিউটার প্রিন্ট",
    description: "সাদা-কালো ও রঙিন প্রিন্ট আউট",
    price: 20,
    icon: "printer",
    color: "rose",
  },
  {
    name: "পাসপোর্ট সাইজ ছবি",
    description: "স্টুডিও কোয়ালিটি পাসপোর্ট / স্ট্যাম্প সাইজ ছবি",
    price: 150,
    icon: "camera",
    color: "orange",
  },
  {
    name: "লামিনেটিং",
    description: "কার্ড ও ডকুমেন্ট লামিনেশন",
    price: 50,
    icon: "layers",
    color: "teal",
  },
  {
    name: "অনলাইন ফরম পূরণ",
    description: "ভর্তি, ব্যাংক, বিদ্যুৎ বিলসহ সব ধরনের অনলাইন ফরম",
    price: 100,
    icon: "file-text",
    color: "indigo",
  },
  {
    name: "বিকাশ / নগদ ক্যাশ সার্ভিস",
    description: "মোবাইল ব্যাংকিং লেনদেন সহায়তা",
    price: 20,
    icon: "smartphone",
    color: "pink",
  },
];
