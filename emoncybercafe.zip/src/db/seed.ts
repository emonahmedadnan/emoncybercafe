import "dotenv/config";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { db } from "./index";
import { customers, orders, payments, services, users } from "./schema";
import { DEFAULT_SERVICES } from "./default-services";

/* Deterministic PRNG so reseeds look similar */
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(42);
const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];
const int = (min: number, max: number) => min + Math.floor(rand() * (max - min + 1));

const DEMO_EMAIL = "admin@amarekta.com";
const now = Date.now();
const hoursAgo = (h: number) => new Date(now - h * 36e5);

const CUSTOMER_DATA: Array<[string, string, string]> = [
  ["মোঃ রহিম উদ্দিন", "01712345678", "সাহেব বাজার, রাজশাহী"],
  ["ফাতেমা খাতুন", "01823456789", "উপশহর, সিলেট"],
  ["আব্দুল করিম", "01934567890", "বোয়ালিয়া, রাজশাহী"],
  ["মোসাঃ সালমা বেগম", "01645678901", "জিন্নাহ পাড়া, চট্টগ্রাম"],
  ["শেখ ফরিদ", "01756789012", "মীরপুর-১০, ঢাকা"],
  ["নুজহাত ইয়াসমিন", "01567890123", "জোড়পুকুর, কুমিল্লা"],
  ["মোঃ জামাল হোসেন", "01878901234", "শিবগঞ্জ, চাঁপাইনবাবগঞ্জ"],
  ["রোকেয়া সুলতানা", "01989012345", "গোয়ালপাড়া, মাগুরা"],
  ["আলাউদ্দিন মিয়া", "01690123456", "চারঘাট, রাজশাহী"],
  ["সুমাইয়া আক্তার", "01701234567", "কুমারপাড়া, সিলেট"],
  ["মোঃ বেলাল হোসেন", "01811223344", "পুরান বাজার, নওগাঁ"],
  ["তাহমিনা পারভীন", "01922334455", "ধানমন্ডি, ঢাকা"],
  ["শফিকুল ইসলাম", "01633445566", "বাঘমারা, রাজশাহী"],
  ["মমতাজ বেগম", "01744556677", "পূবাইল, গাজীপুর"],
  ["রফিকুল ইসলাম", "01855667788", "তানোর, রাজশাহী"],
];

async function main() {
  console.log("🌱 সিড শুরু হচ্ছে…");

  // Idempotent: wipe previous demo tenant (cascades to everything)
  await db.delete(users).where(eq(users.email, DEMO_EMAIL));

  const [admin] = await db
    .insert(users)
    .values({
      name: "মোঃ আকবর হোসেন",
      email: DEMO_EMAIL,
      passwordHash: await bcrypt.hash("123456", 10),
      shopName: "ইমন সাইবার ক্যাফে",
    })
    .returning();
  console.log(`✅ ইউজার তৈরি: ${admin.email}`);

  const svcRows = await db
    .insert(services)
    .values(DEFAULT_SERVICES.map((s) => ({ ...s, userId: admin.id })))
    .returning();
  const svcByIcon = new Map(svcRows.map((s) => [s.icon, s]));
  console.log(`✅ সার্ভিস: ${svcRows.length}টি`);

  const custRows = await db
    .insert(customers)
    .values(
      CUSTOMER_DATA.map(([name, phone, address], i) => ({
        userId: admin.id,
        name,
        phone,
        address,
        createdAt: new Date(now - (45 - i * 2.5) * 864e5),
      }))
    )
    .returning();
  console.log(`✅ গ্রাহক: ${custRows.length} জন`);

  // Weighted service chooser — everyday jobs show up more often
  const jobPool: Array<{ icon: string; weight: number; qty: () => number }> = [
    { icon: "briefcase", weight: 22, qty: () => 1 },
    { icon: "book-user", weight: 16, qty: () => 1 },
    { icon: "baby", weight: 12, qty: () => 1 },
    { icon: "id-card", weight: 14, qty: () => 1 },
    { icon: "copy", weight: 14, qty: () => int(10, 90) },
    { icon: "printer", weight: 8, qty: () => int(2, 25) },
    { icon: "camera", weight: 6, qty: () => 1 },
    { icon: "layers", weight: 3, qty: () => int(1, 6) },
    { icon: "file-text", weight: 4, qty: () => 1 },
    { icon: "smartphone", weight: 1, qty: () => 1 },
  ];
  const totalWeight = jobPool.reduce((s, j) => s + j.weight, 0);
  function pickJob() {
    let r = rand() * totalWeight;
    for (const j of jobPool) {
      r -= j.weight;
      if (r <= 0) return j;
    }
    return jobPool[0];
  }

  // Age profile in hours: heavy recent activity so the dashboard feels alive
  const ageProfile: number[] = [
    1, 2.5, 5, 8, 12, 18, 26, 34, 44, 55, // last ~2 days (10 orders)
    3 * 24, 3.5 * 24, 4 * 24, 5 * 24, 6 * 24, 7 * 24, // last week
    9 * 24, 11 * 24, 13 * 24, 15 * 24, 17 * 24, // last ~2.5 weeks
    20 * 24, 23 * 24, 26 * 24, 29 * 24, 32 * 24, 35 * 24, 38 * 24, 41 * 24, 44 * 24,
  ];

  const dueOrders: Array<{ id: number; due: number; customerId: number }> = [];

  for (const hours of ageProfile) {
    const job = pickJob();
    const svc = svcByIcon.get(job.icon)!;
    const qty = job.qty();
    const total = svc.price * qty;
    const ts = new Date(hoursAgo(hours).getTime() - rand() * 2 * 36e5);

    let status: string;
    if (hours > 24 * 8) {
      status = rand() < 0.85 ? "delivered" : "completed";
    } else if (hours > 24 * 3) {
      status = pick(["delivered", "completed", "completed", "in_progress"]);
    } else {
      status = pick(["pending", "in_progress", "in_progress", "completed"]);
    }

    let paid = 0;
    if (status === "delivered") paid = total;
    else if (status === "completed") paid = rand() < 0.9 ? total : Math.round(total * 0.5);
    else paid = rand() < 0.45 ? Math.round(total * 0.5) : rand() < 0.35 ? total : 0;

    const customer = pick(custRows);
    const [row] = await db
      .insert(orders)
      .values({
        userId: admin.id,
        customerId: customer.id,
        serviceId: svc.id,
        serviceName: svc.name,
        quantity: qty,
        status,
        totalAmount: total,
        paidAmount: paid,
        note:
          rand() < 0.22
            ? pick([
                "রশিদ নম্বর ফোনে পাঠাতে হবে",
                "জরুরি কাজ — আগে দিতে হবে",
                "ডকুমেন্ট পরে আনবে",
                "SMS এসেছে কি না দেখতে হবে",
              ])
            : null,
        deliveryDate: rand() < 0.45 ? new Date(ts.getTime() + int(1, 5) * 864e5) : null,
        createdAt: ts,
        updatedAt: ts,
      })
      .returning();

    if (paid > 0) {
      const split = paid < total && rand() < 0.5;
      if (!split) {
        await db.insert(payments).values({
          userId: admin.id,
          orderId: row.id,
          customerId: customer.id,
          amount: paid,
          method: rand() < 0.75 ? "cash" : rand() < 0.6 ? "bkash" : "nagad",
          note: paid === total ? "পুরো টাকা" : "অগ্রিম",
          createdAt: new Date(ts.getTime() + int(5, 90) * 60e3),
        });
      } else {
        const advance = Math.ceil(paid / 2);
        await db.insert(payments).values([
          {
            userId: admin.id,
            orderId: row.id,
            customerId: customer.id,
            amount: advance,
            method: "cash",
            note: "অগ্রিম",
            createdAt: new Date(ts.getTime() + int(5, 90) * 60e3),
          },
          {
            userId: admin.id,
            orderId: row.id,
            customerId: customer.id,
            amount: paid - advance,
            method: rand() < 0.7 ? "cash" : "bkash",
            note: "বাকি পরিশোধ",
            createdAt: new Date(Math.min(ts.getTime() + int(1, 4) * 864e5, now - 36e5)),
          },
        ]);
      }
    }

    if (paid < total && status !== "pending") {
      dueOrders.push({ id: row.id, due: total - paid, customerId: customer.id });
    }
  }

  // Two old dues collected today & yesterday → lively income numbers
  for (const [i, d] of dueOrders.slice(0, 2).entries()) {
    const ts = i === 0 ? hoursAgo(2) : hoursAgo(27);
    await db.insert(payments).values({
      userId: admin.id,
      orderId: d.id,
      customerId: d.customerId,
      amount: d.due,
      method: i === 0 ? "cash" : "bkash",
      note: "পুরনো বাকি পরিশোধ",
      createdAt: ts,
    });
    const current = await db.query.orders.findFirst({ where: eq(orders.id, d.id) });
    if (current) {
      await db
        .update(orders)
        .set({ paidAmount: current.totalAmount, updatedAt: ts })
        .where(eq(orders.id, d.id));
    }
  }

  console.log("✅ অর্ডার + পেমেন্ট সিড সম্পন্ন");
}

main()
  .then(() => {
    console.log("🎉 ডেমো ডেটা প্রস্তুত!");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
