import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import AuthForm from "@/components/auth-form";
import {
  Baby,
  Banknote,
  BookUser,
  Briefcase,
  Camera,
  CheckCircle2,
  Copy,
  FileText,
  IdCard,
  Printer,
} from "lucide-react";

export const dynamic = "force-dynamic";

const chips = [
  { icon: Briefcase, label: "চাকরির আবেদন" },
  { icon: BookUser, label: "পাসপোর্ট" },
  { icon: Baby, label: "জন্ম নিবন্ধন" },
  { icon: IdCard, label: "NID সেবা" },
  { icon: Copy, label: "ফটোকপি" },
  { icon: Printer, label: "প্রিন্ট" },
  { icon: Camera, label: "পাসপোর্ট ছবি" },
  { icon: FileText, label: "অনলাইন ফরম" },
];

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect("/dashboard");

  return (
    <main className="min-h-screen lg:grid lg:grid-cols-[1.05fr_1fr]">
      {/* -------- Brand panel -------- */}
      <section className="relative hidden overflow-hidden bg-ink-950 text-white lg:flex lg:flex-col lg:justify-between p-10 xl:p-14">
        <div className="dot-grid absolute inset-0" />
        <div className="absolute -top-40 -right-40 h-[480px] w-[480px] rounded-full bg-brand-600/25 blur-[120px]" />
        <div className="absolute bottom-0 -left-32 h-[420px] w-[420px] rounded-full bg-coin-500/15 blur-[110px]" />

        {/* floating mini cards */}
        <div className="pointer-events-none absolute right-10 top-24 hidden xl:block animate-float" style={{ ["--fl-rot" as never]: "4deg" }}>
          <div className="w-52 rounded-2xl border border-white/10 bg-white/[0.06] p-4 shadow-lift backdrop-blur-md">
            <div className="flex items-center gap-2 text-xs text-white/60">
              <Banknote className="h-3.5 w-3.5 text-coin-300" /> আজকের আয়
            </div>
            <div className="mt-1.5 text-2xl font-bold text-coin-300">৳২,৪৫০</div>
            <div className="mt-1 text-[11px] text-white/45">গতকালের চেয়ে ১৮% বেশি</div>
          </div>
        </div>
        <div className="pointer-events-none absolute right-40 top-80 hidden xl:block animate-float-late" style={{ ["--fl-rot" as never]: "-3deg" }}>
          <div className="w-48 rounded-2xl border border-white/10 bg-white/[0.06] p-4 shadow-lift backdrop-blur-md">
            <div className="flex items-center gap-2 text-xs text-white/60">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand-300" /> কাজ সম্পন্ন
            </div>
            <div className="mt-1.5 text-2xl font-bold text-brand-300">১২টি</div>
            <div className="mt-1 text-[11px] text-white/45">এই সপ্তাহে</div>
          </div>
        </div>

        <div className="relative flex items-center gap-3">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-700 text-2xl font-bold shadow-lift">
            ই
          </div>
          <div>
            <div className="text-lg font-bold leading-tight">ইমন সাইবার ক্যাফে</div>
            <div className="text-xs text-white/50">সব ধরনের অনলাইন সেবা এক ঠিকানায়</div>
          </div>
        </div>

        <div className="relative max-w-xl">
          <h1 className="text-4xl font-bold leading-[1.25] xl:text-5xl xl:leading-[1.22]">
            দোকানের প্রতিটি কাজ,
            <br />
            প্রতিটি টাকার হিসাব —<span className="text-brand-300"> এখন এক জায়গায়।</span>
          </h1>
          <p className="mt-5 max-w-md text-[15px] leading-relaxed text-white/60">
            গ্রাহক যোগ করুন, কাজের অবস্থা দেখুন, আয়-ব্যয়ের হিসাব রাখুন — বাংলায়, সহজে, মোবাইল ও কম্পিউটারে।
          </p>

          <div className="mt-8 flex flex-wrap gap-2">
            {chips.map((c) => (
              <span
                key={c.label}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.06] px-3 py-1.5 text-xs text-white/75 backdrop-blur"
              >
                <c.icon className="h-3.5 w-3.5 text-brand-300" />
                {c.label}
              </span>
            ))}
          </div>
        </div>

        <div className="relative text-xs text-white/40">
          সারাদেশের সকল চাকরির আবেদন • পাসপোর্ট • জন্ম নিবন্ধন • NID • ফটোকপি
        </div>
      </section>

      {/* -------- Form panel -------- */}
      <section className="relative flex min-h-screen items-center justify-center p-6 dot-grid-dark">
        <div className="absolute right-6 top-6 hidden items-center gap-2 rounded-full border border-ink-200 bg-cream px-3 py-1.5 text-xs text-ink-600 shadow-soft md:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
          দোকান ব্যবস্থাপনা সিস্টেম
        </div>
        <AuthForm />
      </section>
    </main>
  );
}
