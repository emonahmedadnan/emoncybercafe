import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, services } from "@/db/schema";
import { createSession, hashPassword } from "@/lib/auth";
import { DEFAULT_SERVICES } from "@/db/default-services";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");

    if (!name || !email || password.length < 6) {
      return NextResponse.json(
        { error: "নাম, ইমেইল দিন এবং পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে" },
        { status: 400 }
      );
    }

    const existing = await db.query.users.findFirst({
      where: eq(users.email, email),
    });
    if (existing) {
      return NextResponse.json(
        { error: "এই ইমেইলে ইতিমধ্যে অ্যাকাউন্ট আছে" },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(password);
    const [user] = await db
      .insert(users)
      .values({ name, email, passwordHash })
      .returning();

    // Seed default services for the new shop
    await db.insert(services).values(
      DEFAULT_SERVICES.map((s) => ({ ...s, userId: user.id }))
    );

    await createSession(user.id);
    return NextResponse.json({
      user: { id: user.id, name: user.name, email: user.email, shopName: user.shopName },
    });
  } catch {
    return NextResponse.json({ error: "সার্ভার ত্রুটি হয়েছে" }, { status: 500 });
  }
}
