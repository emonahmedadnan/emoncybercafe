import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { computeStats } from "@/lib/queries";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  return NextResponse.json(await computeStats(user.id));
}
