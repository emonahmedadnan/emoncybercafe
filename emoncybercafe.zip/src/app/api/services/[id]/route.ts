import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { services } from "@/db/schema";
import { requireUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const body = await req.json();

  const patch: Record<string, unknown> = {};
  if (body.name !== undefined) patch.name = String(body.name).trim();
  if (body.description !== undefined)
    patch.description = body.description ? String(body.description).trim() : null;
  if (body.price !== undefined) patch.price = Math.max(0, Math.round(Number(body.price) || 0));
  if (body.icon !== undefined) patch.icon = String(body.icon);
  if (body.color !== undefined) patch.color = String(body.color);
  if (body.active !== undefined) patch.active = Boolean(body.active);

  const [row] = await db
    .update(services)
    .set(patch)
    .where(and(eq(services.id, Number(id)), eq(services.userId, user.id)))
    .returning();

  if (!row) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });
  return NextResponse.json({ service: row });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db
    .delete(services)
    .where(and(eq(services.id, Number(id)), eq(services.userId, user.id)))
    .returning({ id: services.id });

  if (!row) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
