import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { services } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { listServices } from "@/lib/queries";

export async function GET() {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  return NextResponse.json({ services: await listServices(user.id) });
}

export async function POST(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json();
  const name = String(body.name ?? "").trim();
  if (!name) return NextResponse.json({ error: "সার্ভিসের নাম দিন" }, { status: 400 });

  const [row] = await db
    .insert(services)
    .values({
      userId: user.id,
      name,
      description: body.description ? String(body.description).trim() : null,
      price: Math.max(0, Math.round(Number(body.price) || 0)),
      icon: body.icon ? String(body.icon) : "file-text",
      color: body.color ? String(body.color) : "emerald",
      active: body.active !== false,
    })
    .returning();

  return NextResponse.json({ service: { ...row, ordersCount: 0, revenue: 0 } });
}
