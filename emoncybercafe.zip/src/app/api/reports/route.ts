import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { computeReport } from "@/lib/queries";

export async function GET(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const month = req.nextUrl.searchParams.get("month") || undefined;
  return NextResponse.json(await computeReport(user.id, month));
}
