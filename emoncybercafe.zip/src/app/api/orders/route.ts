import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders, payments, services, ORDER_STATUSES } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { listOrders } from "@/lib/queries";

export async function GET(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const status = req.nextUrl.searchParams.get("status") || undefined;
  const q = req.nextUrl.searchParams.get("q")?.trim() || undefined;

  return NextResponse.json({ orders: await listOrders(user.id, { status, q }) });
}

export async function POST(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json();
  const customerId = Number(body.customerId);
  if (!customerId) return NextResponse.json({ error: "গ্রাহক নির্বাচন করুন" }, { status: 400 });

  const customer = await db.query.customers.findFirst({
    where: and(eq(customers.id, customerId), eq(customers.userId, user.id)),
  });
  if (!customer) return NextResponse.json({ error: "গ্রাহক পাওয়া যায়নি" }, { status: 404 });

  let serviceName = body.serviceName ? String(body.serviceName).trim() : "";
  let serviceId: number | null = null;
  let unitPrice = Math.max(0, Math.round(Number(body.unitPrice) || 0));

  if (body.serviceId) {
    const service = await db.query.services.findFirst({
      where: and(eq(services.id, Number(body.serviceId)), eq(services.userId, user.id)),
    });
    if (service) {
      serviceId = service.id;
      serviceName = service.name;
      if (!unitPrice) unitPrice = service.price;
    }
  }
  if (!serviceName) serviceName = "সাধারণ সার্ভিস";

  const quantity = Math.max(1, Math.round(Number(body.quantity) || 1));
  const totalAmount =
    body.totalAmount !== undefined && body.totalAmount !== null && body.totalAmount !== ""
      ? Math.max(0, Math.round(Number(body.totalAmount)))
      : unitPrice * quantity;
  const paidAmount = Math.min(totalAmount, Math.max(0, Math.round(Number(body.paidAmount) || 0)));
  const status = ORDER_STATUSES.includes(body.status) ? body.status : "pending";

  const [row] = await db
    .insert(orders)
    .values({
      userId: user.id,
      customerId,
      serviceId,
      serviceName,
      quantity,
      status,
      totalAmount,
      paidAmount,
      note: body.note ? String(body.note).trim() : null,
      deliveryDate: body.deliveryDate ? new Date(body.deliveryDate) : null,
    })
    .returning();

  if (paidAmount > 0) {
    await db.insert(payments).values({
      userId: user.id,
      orderId: row.id,
      customerId,
      amount: paidAmount,
      method: body.method === "bkash" || body.method === "nagad" ? body.method : "cash",
      note: "অগ্রিম",
    });
  }

  return NextResponse.json({
    order: {
      ...row,
      serviceIcon: null,
      customer: { id: customer.id, name: customer.name, phone: customer.phone },
    },
  });
}
