import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, payments, ORDER_STATUSES } from "@/db/schema";
import { requireUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;

  const existing = await db.query.orders.findFirst({
    where: and(eq(orders.id, Number(id)), eq(orders.userId, user.id)),
  });
  if (!existing) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });

  const body = await req.json();
  const patch: Record<string, unknown> = { updatedAt: new Date() };

  if (body.status !== undefined && ORDER_STATUSES.includes(body.status)) {
    patch.status = body.status;
  }
  if (body.note !== undefined) patch.note = body.note ? String(body.note).trim() : null;
  if (body.quantity !== undefined) patch.quantity = Math.max(1, Math.round(Number(body.quantity) || 1));
  if (body.totalAmount !== undefined)
    patch.totalAmount = Math.max(0, Math.round(Number(body.totalAmount) || 0));
  if (body.deliveryDate !== undefined)
    patch.deliveryDate = body.deliveryDate ? new Date(body.deliveryDate) : null;
  if (body.serviceName !== undefined && String(body.serviceName).trim())
    patch.serviceName = String(body.serviceName).trim();

  let paymentDelta = 0;
  if (body.paidAmount !== undefined) {
    const newPaid = Math.max(0, Math.round(Number(body.paidAmount) || 0));
    const total = (patch.totalAmount as number) ?? existing.totalAmount;
    patch.paidAmount = Math.min(newPaid, total === 0 ? newPaid : total);
    paymentDelta = (patch.paidAmount as number) - existing.paidAmount;
  }

  const [row] = await db
    .update(orders)
    .set(patch)
    .where(and(eq(orders.id, Number(id)), eq(orders.userId, user.id)))
    .returning();

  if (paymentDelta > 0) {
    await db.insert(payments).values({
      userId: user.id,
      orderId: row.id,
      customerId: row.customerId,
      amount: paymentDelta,
      method: body.method === "bkash" || body.method === "nagad" ? body.method : "cash",
      note: "বাকি পরিশোধ",
    });
  }

  return NextResponse.json({ order: row });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db
    .delete(orders)
    .where(and(eq(orders.id, Number(id)), eq(orders.userId, user.id)))
    .returning({ id: orders.id });

  if (!row) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
