import { NextRequest, NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { orders, payments } from "@/db/schema";
import { requireUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;

  const order = await db.query.orders.findFirst({
    where: and(eq(orders.id, Number(id)), eq(orders.userId, user.id)),
  });
  if (!order) return NextResponse.json({ error: "অর্ডার পাওয়া যায়নি" }, { status: 404 });

  const body = await req.json();
  const amount = Math.max(0, Math.round(Number(body.amount) || 0));
  if (!amount) return NextResponse.json({ error: "টাকার পরিমাণ দিন" }, { status: 400 });

  const [payment] = await db
    .insert(payments)
    .values({
      userId: user.id,
      orderId: order.id,
      customerId: order.customerId,
      amount,
      method: body.method === "bkash" || body.method === "nagad" ? body.method : "cash",
      note: body.note ? String(body.note).trim() : null,
    })
    .returning();

  const [updated] = await db
    .update(orders)
    .set({ paidAmount: sql`${orders.paidAmount} + ${amount}`, updatedAt: new Date() })
    .where(eq(orders.id, order.id))
    .returning();

  return NextResponse.json({ payment, order: updated });
}
