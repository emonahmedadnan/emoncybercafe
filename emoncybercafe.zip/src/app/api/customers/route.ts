import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { listCustomers } from "@/lib/queries";

export async function GET(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const q = req.nextUrl.searchParams.get("q")?.trim() || undefined;
  return NextResponse.json({ customers: await listCustomers(user.id, q) });
}

export async function POST(req: NextRequest) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json();
  const name = String(body.name ?? "").trim();
  const phone = String(body.phone ?? "").trim();
  if (!name || !phone) {
    return NextResponse.json({ error: "নাম ও ফোন নম্বর আবশ্যক" }, { status: 400 });
  }

  const [row] = await db
    .insert(customers)
    .values({
      userId: user.id,
      name,
      phone,
      email: body.email ? String(body.email).trim() : null,
      address: body.address ? String(body.address).trim() : null,
      note: body.note ? String(body.note).trim() : null,
    })
    .returning();

  return NextResponse.json({ customer: { ...row, ordersCount: 0, totalBilled: 0, totalDue: 0 } });
}
