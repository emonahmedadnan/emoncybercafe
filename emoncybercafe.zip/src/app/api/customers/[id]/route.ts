import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { requireUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const body = await req.json();

  const [row] = await db
    .update(customers)
    .set({
      name: String(body.name ?? "").trim(),
      phone: String(body.phone ?? "").trim(),
      email: body.email ? String(body.email).trim() : null,
      address: body.address ? String(body.address).trim() : null,
      note: body.note ? String(body.note).trim() : null,
    })
    .where(and(eq(customers.id, Number(id)), eq(customers.userId, user.id)))
    .returning();

  if (!row) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });
  return NextResponse.json({ customer: row });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await requireUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db
    .delete(customers)
    .where(and(eq(customers.id, Number(id)), eq(customers.userId, user.id)))
    .returning({ id: customers.id });

  if (!row) return NextResponse.json({ error: "পাওয়া যায়নি" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
