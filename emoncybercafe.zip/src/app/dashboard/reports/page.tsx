import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { computeReport } from "@/lib/queries";
import ReportsClient from "@/components/reports-client";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const report = await computeReport(user.id);
  return <ReportsClient initialReport={JSON.parse(JSON.stringify(report))} />;
}
