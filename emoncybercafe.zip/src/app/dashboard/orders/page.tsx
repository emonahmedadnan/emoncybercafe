import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { listCustomers, listOrders, listServices } from "@/lib/queries";
import OrdersClient from "@/components/orders-client";

export const dynamic = "force-dynamic";

export default async function OrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ new?: string }>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const { new: openNew } = await searchParams;

  const [orders, customers, services] = await Promise.all([
    listOrders(user.id),
    listCustomers(user.id),
    listServices(user.id),
  ]);

  return (
    <OrdersClient
      initialOrders={JSON.parse(JSON.stringify(orders))}
      customers={JSON.parse(JSON.stringify(customers))}
      services={JSON.parse(JSON.stringify(services.filter((s) => s.active)))}
      openNew={openNew === "1"}
    />
  );
}
