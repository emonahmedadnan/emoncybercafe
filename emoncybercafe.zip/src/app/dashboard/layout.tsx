import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import DashboardShell from "@/components/dashboard-shell";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  return (
    <DashboardShell
      user={{ name: user.name, email: user.email, shopName: user.shopName }}
    >
      {children}
    </DashboardShell>
  );
}
