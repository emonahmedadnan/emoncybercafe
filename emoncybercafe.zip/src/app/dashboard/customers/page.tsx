import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { listCustomers } from "@/lib/queries";
import CustomersClient from "@/components/customers-client";

export const dynamic = "force-dynamic";

export default async function CustomersPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const customers = await listCustomers(user.id);
  return <CustomersClient initialCustomers={JSON.parse(JSON.stringify(customers))} />;
}
