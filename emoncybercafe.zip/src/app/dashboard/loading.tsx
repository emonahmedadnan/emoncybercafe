import { CardSkeleton } from "@/components/ui";

export default function DashboardLoading() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <CardSkeleton key={i} />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-5">
        <div className="h-72 animate-pulse rounded-2xl border border-ink-100 bg-cream lg:col-span-3" />
        <div className="h-72 animate-pulse rounded-2xl border border-ink-100 bg-cream lg:col-span-2" />
      </div>
      <div className="h-80 animate-pulse rounded-2xl border border-ink-100 bg-cream" />
    </div>
  );
}
