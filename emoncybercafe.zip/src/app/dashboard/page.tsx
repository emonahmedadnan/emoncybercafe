import { computeStats, listOrders } from "@/lib/queries";
import DashboardClient from "@/components/dashboard-client";
import { getSessionUser } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const [stats, recentOrders] = await Promise.all([
    computeStats(user.id),
    listOrders(user.id),
  ]);

  return (
    <DashboardClient
      stats={JSON.parse(JSON.stringify(stats))}
      recentOrders={JSON.parse(JSON.stringify(recentOrders.slice(0, 7)))}
      userName={user.name}
    />
  );
}
