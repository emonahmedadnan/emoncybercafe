import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { listServices } from "@/lib/queries";
import ServicesClient from "@/components/services-client";

export const dynamic = "force-dynamic";

export default async function ServicesPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const services = await listServices(user.id);
  return <ServicesClient initialServices={JSON.parse(JSON.stringify(services))} />;
}
