const BN_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];

/** Convert ASCII digits in a string/number to Bengali digits */
export function toBn(value: number | string): string {
  return String(value).replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);
}

/** Indian-style grouping (১,২৫,০০০) in Bengali digits */
function groupIndian(n: number): string {
  const s = Math.abs(Math.round(n)).toString();
  if (s.length <= 3) return toBn(s);
  const last3 = s.slice(-3);
  const rest = s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
  return toBn(`${rest},${last3}`);
}

/** ৳১,২৫০ */
export function taka(n: number): string {
  return `৳${groupIndian(n)}`;
}

/** Order number like #১০২৪ */
export function orderNo(id: number): string {
  return `#${toBn(1000 + id)}`;
}

export function bnDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("bn-BD", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function bnDateShort(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("bn-BD", {
    day: "numeric",
    month: "short",
  });
}

export function bnDateTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = new Date(d);
  return `${date.toLocaleDateString("bn-BD", {
    day: "numeric",
    month: "short",
  })}, ${date.toLocaleTimeString("bn-BD", {
    hour: "numeric",
    minute: "2-digit",
  })}`;
}

export const STATUS_META: Record<
  string,
  { label: string; badge: string; dot: string; bar: string }
> = {
  pending: {
    label: "অপেক্ষমাণ",
    badge: "bg-amber-50 text-amber-700 ring-amber-200",
    dot: "bg-amber-500",
    bar: "#f59e0b",
  },
  in_progress: {
    label: "চলমান",
    badge: "bg-sky-50 text-sky-700 ring-sky-200",
    dot: "bg-sky-500",
    bar: "#0ea5e9",
  },
  completed: {
    label: "সম্পন্ন",
    badge: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    dot: "bg-emerald-500",
    bar: "#10b981",
  },
  delivered: {
    label: "ডেলিভার্ড",
    badge: "bg-violet-50 text-violet-700 ring-violet-200",
    dot: "bg-violet-500",
    bar: "#8b5cf6",
  },
};

export function statusLabel(status: string): string {
  return STATUS_META[status]?.label ?? status;
}

export function todayBn(): string {
  return new Date().toLocaleDateString("bn-BD", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
