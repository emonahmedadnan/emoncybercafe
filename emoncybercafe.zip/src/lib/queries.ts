import { and, asc, desc, eq, gte, ilike, lt, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders, payments, services } from "@/db/schema";

export type CustomerRow = {
  id: number;
  name: string;
  phone: string;
  email: string | null;
  address: string | null;
  note: string | null;
  createdAt: Date;
  ordersCount: number;
  totalBilled: number;
  totalDue: number;
};

export async function listCustomers(userId: number, q?: string): Promise<CustomerRow[]> {
  return db
    .select({
      id: customers.id,
      name: customers.name,
      phone: customers.phone,
      email: customers.email,
      address: customers.address,
      note: customers.note,
      createdAt: customers.createdAt,
      ordersCount: sql<number>`count(${orders.id})::int`,
      totalBilled: sql<number>`coalesce(sum(${orders.totalAmount}), 0)::int`,
      totalDue: sql<number>`coalesce(sum(${orders.totalAmount} - ${orders.paidAmount}), 0)::int`,
    })
    .from(customers)
    .leftJoin(orders, eq(orders.customerId, customers.id))
    .where(
      and(
        eq(customers.userId, userId),
        q ? or(ilike(customers.name, `%${q}%`), ilike(customers.phone, `%${q}%`)) : undefined
      )
    )
    .groupBy(customers.id)
    .orderBy(desc(customers.createdAt));
}

export type OrderRow = {
  id: number;
  status: string;
  quantity: number;
  totalAmount: number;
  paidAmount: number;
  note: string | null;
  deliveryDate: Date | null;
  createdAt: Date;
  serviceId: number | null;
  serviceName: string;
  serviceIcon: string | null;
  customer: { id: number; name: string; phone: string };
};

export async function listOrders(
  userId: number,
  opts?: { status?: string; q?: string }
): Promise<OrderRow[]> {
  const { status, q } = opts ?? {};
  return db
    .select({
      id: orders.id,
      status: orders.status,
      quantity: orders.quantity,
      totalAmount: orders.totalAmount,
      paidAmount: orders.paidAmount,
      note: orders.note,
      deliveryDate: orders.deliveryDate,
      createdAt: orders.createdAt,
      serviceId: orders.serviceId,
      serviceName: orders.serviceName,
      serviceIcon: services.icon,
      customer: {
        id: customers.id,
        name: customers.name,
        phone: customers.phone,
      },
    })
    .from(orders)
    .innerJoin(customers, eq(customers.id, orders.customerId))
    .leftJoin(services, eq(services.id, orders.serviceId))
    .where(
      and(
        eq(orders.userId, userId),
        status && status !== "all" ? eq(orders.status, status) : undefined,
        q
          ? or(
              ilike(customers.name, `%${q}%`),
              ilike(orders.serviceName, `%${q}%`),
              ilike(customers.phone, `%${q}%`)
            )
          : undefined
      )
    )
    .orderBy(desc(orders.createdAt));
}

export type ServiceRow = {
  id: number;
  name: string;
  description: string | null;
  price: number;
  icon: string;
  color: string;
  active: boolean;
  ordersCount: number;
  revenue: number;
};

export async function listServices(userId: number): Promise<ServiceRow[]> {
  return db
    .select({
      id: services.id,
      name: services.name,
      description: services.description,
      price: services.price,
      icon: services.icon,
      color: services.color,
      active: services.active,
      ordersCount: sql<number>`count(${orders.id})::int`,
      revenue: sql<number>`coalesce(sum(${orders.paidAmount}), 0)::int`,
    })
    .from(services)
    .leftJoin(orders, eq(orders.serviceId, services.id))
    .where(eq(services.userId, userId))
    .groupBy(services.id)
    .orderBy(asc(services.id));
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export async function computeStats(userId: number) {
  const [allCustomers, allOrders, allPayments] = await Promise.all([
    db.select({ id: customers.id }).from(customers).where(eq(customers.userId, userId)),
    db.query.orders.findMany({
      where: eq(orders.userId, userId),
      orderBy: [desc(orders.createdAt)],
    }),
    db
      .select({ amount: payments.amount, createdAt: payments.createdAt, method: payments.method })
      .from(payments)
      .where(eq(payments.userId, userId)),
  ]);

  const today = startOfDay(new Date());
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

  const todayIncome = allPayments
    .filter((p) => p.createdAt >= today)
    .reduce((s, p) => s + p.amount, 0);
  const monthIncome = allPayments
    .filter((p) => p.createdAt >= monthStart)
    .reduce((s, p) => s + p.amount, 0);
  const totalDue = allOrders.reduce((s, o) => s + Math.max(0, o.totalAmount - o.paidAmount), 0);

  const statusCounts: Record<string, number> = {
    pending: 0,
    in_progress: 0,
    completed: 0,
    delivered: 0,
  };
  for (const o of allOrders) statusCounts[o.status] = (statusCounts[o.status] ?? 0) + 1;

  const weekIncome: Array<{ label: string; amount: number; isToday: boolean }> = [];
  for (let i = 6; i >= 0; i--) {
    const day = new Date(today);
    day.setDate(day.getDate() - i);
    const next = new Date(day);
    next.setDate(next.getDate() + 1);
    const amount = allPayments
      .filter((p) => p.createdAt >= day && p.createdAt < next)
      .reduce((s, p) => s + p.amount, 0);
    weekIncome.push({
      label: day.toLocaleDateString("bn-BD", { weekday: "short" }),
      amount,
      isToday: i === 0,
    });
  }

  const byService = new Map<string, { count: number; revenue: number }>();
  for (const o of allOrders) {
    const cur = byService.get(o.serviceName) ?? { count: 0, revenue: 0 };
    cur.count += 1;
    cur.revenue += o.paidAmount;
    byService.set(o.serviceName, cur);
  }
  const topServices = [...byService.entries()]
    .map(([name, v]) => ({ name, ...v }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return {
    totalCustomers: allCustomers.length,
    activeOrders: statusCounts.pending + statusCounts.in_progress,
    totalOrders: allOrders.length,
    todayIncome,
    monthIncome,
    totalDue,
    statusCounts,
    weekIncome,
    topServices,
  };
}

export async function computeReport(userId: number, monthParam?: string) {
  const now = new Date();
  const [yr, mo] = (monthParam ?? `${now.getFullYear()}-${now.getMonth() + 1}`)
    .split("-")
    .map((x) => Number(x));
  const start = new Date(yr, mo - 1, 1);
  const end = new Date(yr, mo, 1);

  const [monthPayments, monthOrders] = await Promise.all([
    db
      .select({
        id: payments.id,
        amount: payments.amount,
        method: payments.method,
        note: payments.note,
        createdAt: payments.createdAt,
        orderId: payments.orderId,
        customerName: customers.name,
        serviceName: orders.serviceName,
      })
      .from(payments)
      .innerJoin(customers, eq(customers.id, payments.customerId))
      .innerJoin(orders, eq(orders.id, payments.orderId))
      .where(
        and(eq(payments.userId, userId), gte(payments.createdAt, start), lt(payments.createdAt, end))
      )
      .orderBy(desc(payments.createdAt)),
    db
      .select({
        id: orders.id,
        status: orders.status,
        totalAmount: orders.totalAmount,
        paidAmount: orders.paidAmount,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .where(and(eq(orders.userId, userId), gte(orders.createdAt, start), lt(orders.createdAt, end))),
  ]);

  const daysInMonth = new Date(yr, mo, 0).getDate();
  const daily: Array<{ day: number; amount: number }> = Array.from(
    { length: daysInMonth },
    (_, i) => ({ day: i + 1, amount: 0 })
  );
  let totalIncome = 0;
  const byMethod: Record<string, number> = { cash: 0, bkash: 0, nagad: 0 };
  for (const p of monthPayments) {
    daily[p.createdAt.getDate() - 1].amount += p.amount;
    totalIncome += p.amount;
    byMethod[p.method] = (byMethod[p.method] ?? 0) + p.amount;
  }

  return {
    month: `${yr}-${String(mo).padStart(2, "0")}`,
    monthLabel: start.toLocaleDateString("bn-BD", { month: "long", year: "numeric" }),
    totalIncome,
    paymentsCount: monthPayments.length,
    ordersCount: monthOrders.length,
    ordersBilled: monthOrders.reduce((s, o) => s + o.totalAmount, 0),
    ordersCollected: monthOrders.reduce((s, o) => s + Math.min(o.paidAmount, o.totalAmount), 0),
    daily,
    byMethod,
    ledger: monthPayments.slice(0, 60),
  };
}
